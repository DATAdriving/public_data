import random
from plotData import *
import numpy as np
from structure import *
from utils import *
from AIA_utils import *
from VNS import *
from tabu_search import *
import csv



def calRelation(removed,inplan,isOneroute):
    R=np.zeros(len(inplan))
    ranCus=random.choice(removed)
    temp_distance=customer_distance_mat[ranCus]
    maxDis=0
    for k in temp_distance:
        if k>maxDis and k!=float("inf"):
            maxDis=k
    # maxDis = max(temp_distance)
    for j in range(len(inplan)):
        cus=inplan[j]
        R[j]=1/(customer_distance_mat[ranCus][cus]/maxDis+isOneroute[ranCus][cus])
    newR=np.zeros(len(inplan))
    sumR=0
    for x in R:
        sumR+=x
    for i in range(len(R)):
        newR[i]=R[i]/sumR
    return newR


'''
random.randint(1,100):
        包括1和100
'''
def destroy(solution):

    isOneroute=np.zeros((customers_account,customers_account),dtype='int')
    for route in solution:
        for i,index in zip(route[1:-1],range(1,len(route[1:-1]))):
            for j in route[index:-1]:
                isOneroute[i][j]=1
                isOneroute[j][i]=1
    inplan=list(range(1,customers_account))
    toRemove=9

    temp = list(range(len(solution) - 1))
    randrouteindex = random.choice(temp)
    randroute = solution[randrouteindex]
    if len(randroute) == 2:
        temp.remove(randrouteindex)
        randrouteindex = random.choice(temp)
        randroute = solution[randrouteindex]

    # randroute=random.randint(0,len(solution)-1)
    # visit=random.choice(solution[randroute][1:-1])
    visit = random.choice(randroute[1:-1])
    removed=[visit]
    inplan.remove(visit)
    # 按照轮盘赌原则选择下一个顾客
    while len(removed)<toRemove:
        R = calRelation(removed, inplan, isOneroute)
        rand = random.random()
        for i in range(len(R)):
            if R[i]>rand:
                visit=inplan[i]
                break
            else:
                rand=rand-R[i]
        removed.append(visit)
        inplan.remove(visit)
    # 记录下来removed中的元素都在哪条路径的哪个位置
    i_route=[]
    j_route=[]
    for x in removed:
        for route,i in zip(solution,range(len(solution))):
            for cus,j in zip(route,range(len(route))):
                if x==cus:
                    i_route.append(i)
                    j_route.append(j)
                    route.remove(cus)
    return solution,removed


def repair(original_fit,solution,removed):
    # print(original_fit)
    # solution.append([0,0])
    Best_fitness = original_fit
    last=[0,0]
    next=[0,0]
    for number,i in zip(removed,range(len(removed))): #remove中的第几个元素
        # Best_fitness = float('inf')
        temp,R,P=[],[],[]
        for m in range(len(solution)):
            routem = solution[m]
            for n in range(1, len(routem)):
                routem.insert(n, number)
                a,b,c,d,e = solution_fitness(solution)
                temp_fitness = calFitness(a,b,c,d,e)
                temp.append(temp_fitness)
                R.append(m)
                P.append(n)
                if temp_fitness <= Best_fitness:
                    print('LNS: temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
                    BestR, BestP = m, n
                    Best_fitness = temp_fitness
                    # Besta,Bestb,Bestc,Bestd=a,b,c,d
                    next=[BestR, BestP]
                routem.pop(n)
        # print('number,BestR,BestP',number, BestR, BestP)
        if last!=next:
            solution[BestR].insert(BestP, number)
            last=[BestR, BestP]
        else:
            index=temp.index(min(temp))
            solution[R[index]].insert(P[index],number)
            Best_fitness = min(temp)
    # return solution, Best_fitness,Besta,Bestb,Bestc,Bestd
    return solution, Best_fitness


def repair2(solution,removed,x_route):
    for number,i in zip(removed,range(len(removed))):
        Best_fitness = float('inf')
        for m in range(len(solution)):
            routem = solution[m]
            # routem_oldFit = route_fitness(routem, m)
            if (len(routem) > 2 and Tabu[number][m] <= Iteration) or (len(routem) == 2 and TabuCreate[number] <= Iteration):
                for n in range(1, len(routem)):
                    routem.insert(n, number)
                    # routem_newFit = route_fitness(routem, m)
                    vehicleNumber, distance, overLoad, punish = solution_fitness(solution)
                    temp_fitness = calFitness(vehicleNumber,distance, overLoad, punish)
                    if temp_fitness < Best_fitness:
                        # print('temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
                        BestR, BestP = m, n
                        Best_fitness = temp_fitness
                    routem.pop(n)
        print('\nnumber,BestR,BestP',number, BestR, BestP)
        if len(solution[BestR]) == 2:
            TabuCreate[number] = Iteration + 2 * Tabu_tenure + random.randint(0, 9)
        number_route=x_route[i]
        Tabu[number][number_route] = Iteration + Tabu_tenure + random.randint(0, 9)
        solution[BestR].insert(BestP, number)
    for route in solution:
        if len(route) == 2:
            solution.remove(route)
    return solution


def initial_solution2(customers):
    def sorted_readytime(customers):  # 按照ready_time进行排序
        return list(sorted(customers, key=lambda customer: customer.ready_time))
    customers = sorted_readytime(customers)
    for customer in customers:
        customer.is_serviced=False
    def get_available_customers(customers):  # 还未访问过的顾客
        return list(filter(lambda customer: not customer.is_serviced, customers))
    customers = get_available_customers(customers)
    solution = []
    vehicleNo=0
    while len(customers) > 0:  # 还有未访问过的顾客时进行循环
        vehicleNow = Vehicle(vehicleNo)
        vehicleNow.route=[depot.number]
        continue_count=0
        capacity_temp = np.zeros(len(vehicleNow.capacity), dtype=int)
        deliCapa_temp = np.zeros(len(vehicleNow.deliCapa), dtype=int)
        last_customer = depot.number
        for customer in customers:  # 确定每一条路径的customer
            distance_depot = customer_distance_mat[customer.number][depot.number]
            start_service_time = max(customer.ready_time,
                                     vehicleNow.time + customer_distance_mat[last_customer][customer.number])
            time_temp = start_service_time + customer.service_time + distance_depot
            capacity_temp_sum = 0
            deliCapa_temp_sum = 0
            customer_pickup = deepcopy(customer.pickup)
            customer_delivery = deepcopy(customer.delivery)
            for i in range(len(vehicleNow.capacity)):
                capacity_temp[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
                capacity_temp_sum += capacity_temp[i]  # 如果总重量超过最大承载能力，换下一个顾客
                deliCapa_temp[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
                deliCapa_temp_sum += deliCapa_temp[i]  # 如果车上没有从仓库运来的物品了，换车
                customer_pickup[i] = 0
                customer_delivery[i] = 0
            if deliCapa_temp_sum < 0 or time_temp > depot.due_time or continue_count > 3:  # 换车
                break
            elif continue_count <= 3 and min(deliCapa_temp) < 0:  # 换下一个顾客
                # elif continue_count <= 3 and (capacity_temp_sum > vehicle_capacity or min(deliCapa_temp)<0): #换下一个顾客
                continue_count += 1
                continue
            else:
                vehicleNow.time, vehicleNow.capacity, vehicleNow.deliCapa = time_temp - distance_depot, capacity_temp, deliCapa_temp
                customer.pickup_request = customer_pickup
                customer.delivery_request = customer_delivery
                customer.is_serviced = True
                vehicleNow.route.append(customer.number)
            last_customer = customer.number
        vehicleNow.route.append(depot.number)
        solution.append(vehicleNow.route)
        customers = get_available_customers(customers)
        vehicleNo+=1
    return solution


def infeasibleRepair(individual):
    solution=one2many2(individual)
    newSolution=list(solution)
    count = 0
    for route in solution:
        for x in route[1:-1]:
            count += 1
    # if count!=100:
    #     print('修复不可行解前', count)
    for route, vehicleNo in zip(solution, range(len(solution))):  # 对每条路径计算适应度
        is_feasible, routeDistance, routeoverLoad, routePunish = route_fitness(route, vehicleNo)
        if is_feasible == False:
            customers=[]
            for cus in route[1:-1]:
                for x in global_customers:
                    if cus==x.number:
                        customer=x
                        customers.append(customer)
            small_solution=initial_solution2(customers)
            # print_solution(small_solution)
            newSolution.remove(route)
            for small_route in small_solution:
                newSolution.append(small_route)
    # a,b,c,d=solution_fitness(newSolution)
    # fit=calFitness(a,b,c,d)
    if len(newSolution)>24:
        newSolution=Eliminates_Route(newSolution)
    individual=many2one2(newSolution)
    return individual,newSolution



def Tabu_Search2(solution,Alpha,Beta):
    fitness_list=[]
    Iteration = 0
    # ②TS循环开始
    Best_fitness = float('inf')
    last_BestC=[0,0,0,0,0]
    while Iteration < 100:
        print('\n迭代次数：', Iteration)
        print('Alpha,Beta:',Alpha,Beta)
        Iteration = Iteration + 1
        a,b,c,d,e = solution_fitness(solution)
        fitness=[a,b,c,d,e]
        print('fitness',fitness)
        # 2 循环所有客户点 i>1
        for i in range(len(solution)): # i也就是vehicle_No
            routei = solution[i]
            routei_oldFit = route_fitness(routei,i)
            for j in range(len(routei)): # j代表顾客在路径中的位置，也就是P
                if routei[j] != 0:
                    number = routei.pop(j)
                    routei_newFit=route_fitness(routei,i)
                    # 接下来对所有可插入位置进行循环
                    for m in range(len(solution)):
                        routem = solution[m]
                        routem_oldFit=route_fitness(routem,m)
                        if (len(routem)>2 and Tabu[number][m]<=Iteration) or (len(routem)==2 and TabuCreate[number]<=Iteration):
                        # if i!=m and (len(routem)>2 and Tabu[number][m]<=Iteration) or ((len(routem)==2 and TabuCreate[number]<=Iteration)):
                            for n in range(1,len(routem)):
                                routem.insert(n,number)
                                routem_newFit=route_fitness(routem,m)
                                temp_fitness = change_fitness(fitness,routei_oldFit,routei_newFit,routem_oldFit,routem_newFit)
                                if temp_fitness < Best_fitness:
                                    print('temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
                                    BestC,BestC_R,BestC_P,BestR,BestP = number,i,j,m,n
                                    Best_fitness = temp_fitness
                                routem.pop(n)
                    routei.insert(j,number)
        next_BestC=[BestC,BestC_R,BestC_P,BestR,BestP]
        if BestC!=0 and next_BestC!=last_BestC:
            print('BestC,BestC_R,BestC_P,BestR,BestP',BestC,BestC_R,BestC_P,BestR,BestP)
            if len(solution[BestR])==2:
                TabuCreate[BestC] = Iteration + 2 * Tabu_tenure + random.randint(0, 9)
            Tabu[BestC][BestC_R]=Iteration+Tabu_tenure+random.randint(0,9)
            customer = solution[BestC_R].pop(BestC_P)
            solution[BestR].insert(BestP,customer)
        #     temp_fitness = Best_fitness
        # temp_fitness=TS_fitness(solution)
        # if temp_fitness < Best_fitness:
        #     Best_fitness = temp_fitness
        solution,fitness=VNS_implement(solution)
        # print('distance,overLoad,punish',distance,overLoad,punish)
        # print_solution(solution)
        # print(fitness)
        fitness_list.append(fitness)
        last_BestC=[BestC,BestC_R,BestC_P,BestR,BestP]
        Alpha,Beta=updateFitness(overLoad,punish,Alpha,Beta)
    return fitness_list,solution



def LNS(popA, popB):
    population=popA+popB
    for ii in range(1):
        fitnesses=[]
        for individual, j in zip(population, range(len(population))):
            # print('第几个个体', j)
            solution = one2many2(individual)
            a,b,c,d,e=solution_fitness(solution)
            fit=calFitness(a,b,c,d,e)
            if fit!=float('inf'):
                original_solution=list(solution)
                if len(solution)>24:
                    print('LNS用到了消除路径')
                    solution=Eliminates_Route(solution)
                solution, removed= destroy(solution)
                solution, fitness = repair(fit,solution, removed)
                fitnesses.append(fitness)
            else: #先修复不可行解
                population[j],newSolution=infeasibleRepair(individual)
                a,b,c,d,e=solution_fitness(newSolution)
                fit=calFitness(a,b,c,d,e)
                original_solution = list(newSolution)
                if len(newSolution)>24:
                    print('LNS用到了消除路径')
                    newSolution=Eliminates_Route(newSolution)
                solution, removed = destroy(newSolution)
                solution, fitness = repair(fit,solution, removed)
                # solution, fitness = VNS_implement(solution)
                # print('最开始是不可行解',fitness)
                fitnesses.append(fitness)
            population[j] = many2one2(solution)
    min_index=fitnesses.index(min(fitnesses))
    min_individual=population[min_index]
    return population,fitnesses,min_individual,min(fitnesses)



def ILSLNS(original_solution,original_fit):
    solution, removed = destroy(original_solution)
    solution, fitness = repair(original_fit, solution, removed)
    return solution,fitness



if __name__=='__main__':
    f1 = open('LNS-dpc105.csv', 'a', newline='')
    csv_writer1 = csv.writer(f1)
    for ii in range(4):
        algorithm = 'qita'
        start = time.time()
        population, fitnesses = initial_solution(algorithm)
        best_fitness=float('inf')
        for i in range(100):
            fitnesses = []
            for solution, j in zip(population[:2], range(len(population))):
                # print('第几个个体', j)
                a, b, c, d, e = solution_fitness(solution)
                fit = calFitness(a, b, c, d, e)
                if fit != float('inf'):
                    original_solution = list(solution)
                    if len(solution) > 24:
                        print('LNS用到了消除路径')
                        solution = Eliminates_Route(solution)
                    solution, removed = destroy(solution)
                    solution, fitness = repair(fit, original_solution, solution, removed)
                    fitnesses.append(fitness)
                else:  # 先修复不可行解
                    population[j], newSolution = infeasibleRepair(individual)
                    a, b, c, d,e = solution_fitness(newSolution)
                    fit = calFitness(a, b, c, d, e)
                    original_solution = list(newSolution)
                    if len(newSolution) > 24:
                        print('LNS用到了消除路径')
                        newSolution = Eliminates_Route(newSolution)
                    solution, removed = destroy(newSolution)
                    solution, fitness = repair(fit, original_solution, solution, removed)
                    # solution, fitness = VNS_implement(solution)
                    # print('最开始是不可行解',fitness)
                    fitnesses.append(fitness)
                for k in reversed(range(len(solution))):
                    if len(solution[k])==2:
                        print('len(route)==2')
                        # print_solution(solution)
                        del solution[k]
                        # print_solution(solution)

                population[j] = solution
            min_index = fitnesses.index(min(fitnesses))
            min_individual = population[min_index]
            min_fitness=min(fitnesses)
            if min_fitness<best_fitness:
                best_fitness=min_fitness
            print(i,best_fitness,min_fitness)

        end=time.time()
        print('%s' %(end-start),best_fitness)
        csv_writer1.writerow([globalPath, (end - start), fitness])
    f1.close()
    # solution=[[0,33,49,20,5,43,13,32,47,3,0],
    # [0,42,24,17,41,7,25,18,31,8,0],
    # [0,27,40,19,35,10,29,44,0],
    # [0,15,37,46,11,30,16,0],
    # [0,38,9,45,28,14,0],
    # [0,6,39,26,48,0],
    # [0,4,12,36,23,0],
    # [0,21,34,0],
    # [0,1,22,0],
    # [0,2,50,0]]
    # Iteration=0
    # while Iteration<10:
    #     print('\n\n*******************Iteration******************',Iteration)
    #     solution,removed,x_route=destroy(solution)
    #     solution=repair(solution, removed, x_route,Iteration)
    #     print_solution(solution)
    #     Iteration+=1
    # plotRoutes(solution)


