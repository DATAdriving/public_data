from VNS import *
from AIA_utils import *


def updateFitness(overLoad,punish,Alpha,Beta):
    # 更新distance的参数Alpha
    if overLoad==0 and Alpha >= 0.001:
        Alpha = Alpha / (1 + Sita)
    elif overLoad>0 and Alpha <=2000:
        Alpha = Alpha * (1 + Sita)
    # 更新punish的参数Beta
    if punish==0 and Beta >= 0.001:
        Beta = Beta / (1 + Sita)
    elif punish>0 and Beta <= 2000:
        Beta = Beta * ( 1 + Sita )
    return Alpha,Beta

# def Eliminates_Route(solution):
#     count = 0
#     while len(solution)>24:
#         # print('进来了',len(solution))
#         count += 1
#         route_length = [len(route) for route in solution]
#         small_vehicleNo = route_length.index(min(route_length))  # 选择最小路径,vehicle_No
#         small_route = solution[small_vehicleNo]
#         # print('消除最小路径' + str(small_vehicleNo))
#         while len(small_route) > 2:
#             for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route) - 1))):  # 去掉depot
#                 customer = small_route.pop(i)
#                 for m in range(len(solution)): # 换一条路径
#                     if m!=small_vehicleNo:
#                         routem = solution[m]
#                         for n in range(1, len(routem)):
#                             routem.insert(n, customer)
#                             routem_newFit = route_fitness(routem, m)
#                             if routem_newFit[0] == False:
#                                 routem.pop(n)
#                             else:
#                                 break #不用再遍历位置
#                         if customer in routem:
#                             break #不用再遍历路径，决定是否换下一个顾客
#                 if len(small_route) == 2:  # 换下一个顾客
#                     break  # 如果不等于2，要换一条路径
#         del solution[small_vehicleNo]
#     return solution


def Tabu_Search(solution,fitness):
    # if len(solution)>30:
    #     print('TS用到了消除路径')
    #     solution=Eliminates_Route(solution)
    if len(solution) > 29:
        # print('many2one2用到了消除路径')
        solution = Eliminates_Route(solution)
    if len(solution) > 29:
        # print('many2one2用到了消除路径')
        solution = Eliminates_Route(solution)
    fitness_list=[]
    Iteration = 0
    # ②TS循环开始
    # a,b,c,d=solution_fitness(solution)
    # Best_fitness=calFitness(a,b,c,d)
    Best_fitness = float('inf')
    # Best_fitness = fitness
    BestC=0
    last_BestC=[0,0,0,0,0]
    next_BestC=[0,0,0,0,0]
    while Iteration <1: #######################迭代次数##############################
        print('\n迭代次数：', Iteration)
        Iteration = Iteration + 1
        a,b,c,d,e = solution_fitness(solution)
        fit=[a,b,c,d,e]
        fitness=calFitness(a,b,c,d,e)
        print('fitness',fitness)
        # 2 循环所有客户点 i>1
        for i in range(len(solution)): # i也就是vehicle_No
            routei = solution[i]
            routei_oldFit = route_fitness(routei,i)
            for j in range(len(routei)): # j代表顾客在路径中的位置，也就是P
                if routei[j] != 0:
                    number = routei.pop(j)
                    routei_newFit=route_fitness(routei,i)
                    # 接下来对所有可插入位置进行循环
                    for m in range(len(solution)):
                        routem = solution[m]
                        routem_oldFit=route_fitness(routem,m)
                        if (len(routem)>2 and Tabu[number][m]<=Iteration) or (len(routem)==2 and TabuCreate[number]<=Iteration):
                        # if i!=m and (len(routem)>2 and Tabu[number][m]<=Iteration) or ((len(routem)==2 and TabuCreate[number]<=Iteration)):
                            for n in range(1,len(routem)):
                                routem.insert(n,number)
                                routem_newFit=route_fitness(routem,m)
                                temp_fitness = change_fitness(fit,routei_oldFit,routei_newFit,routem_oldFit,routem_newFit)
                                if temp_fitness < Best_fitness:
                                    print('temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
                                    BestC,BestC_R,BestC_P,BestR,BestP = number,i,j,m,n
                                    Best_fitness = temp_fitness
                                    next_BestC = [BestC, BestC_R, BestC_P, BestR, BestP]
                                routem.pop(n)
                    routei.insert(j,number)
        if BestC!=0 and next_BestC!=last_BestC:
            print('BestC,BestC_R,BestC_P,BestR,BestP',BestC,BestC_R,BestC_P,BestR,BestP)
            if len(solution[BestR])==2:
                TabuCreate[BestC] = Iteration + 2 * Tabu_tenure + random.randint(0, 9)
            Tabu[BestC][BestC_R]=Iteration+Tabu_tenure+random.randint(0,9)
            customer = solution[BestC_R].pop(BestC_P)
            solution[BestR].insert(BestP,customer)
        #     temp_fitness = Best_fitness
        # temp_fitness=TS_fitness(solution)
        # if temp_fitness < Best_fitness:
        #     Best_fitness = temp_fitness
        # solution,fitness=VNS_implement(solution)
        # print('distance,overLoad,punish',distance,overLoad,punish)
        # print_solution(solution)
        # print(fitness)
        a,b,c,d,e=solution_fitness(solution)
        fitness=calFitness(a,b,c,d,e)
        fitness_list.append(fitness)
        last_BestC=[BestC,BestC_R,BestC_P,BestR,BestP]
    print('*************************************车辆数目',len(solution),'*************************************')
    return solution, fitness




if __name__ == '__main__':
    start=time.time()

    algorithm='TS'
    solution,fitness = initial_solution(algorithm)
    print_solution(solution)
    print(fitness)
    print('####################################禁忌开始#####################################')
    fitness,solution,fitness_list=Tabu_Search(solution,Alpha,Beta)
    # print(solution)
    # print_solution(solution)
    end=time.time()
    print(globalPath)
    print('%s' % (end - start),fitness)
    # print('fitness',fitness)
    title = 'Tabu Search'  # title of graph
    # plotLines(fitness_list, title,'fitness')
    plotRoutes(solution)
