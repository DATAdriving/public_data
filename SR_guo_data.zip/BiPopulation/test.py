from VNS import *
from AIA_utils import *
from LNS import *
import time
import math
import csv
from ILS import *

pclA, pchA = 0.5, 0.85  # 交叉概率
pclB, pchB = 0.7, 0.95  # 交叉概率

pmA, pmB = 0.25, 0.45  # 变异概率

selectNumber = 10


# 锦标赛选择
def select1(population, fitnesses):
    fitness, density = calDensity(population, fitnesses)
    weightPro = np.zeros(len(population))
    for i in range(len(population)):
        weightPro[i] = fitness[i] + density[i]
    newPopulation = []
    newFitnesses = []

    for i in range(selectNumber):
        sample_number = random.randint(1, int(len(population) / 2) - 1)
        # sample_number=random.randint(1,len(population))
        samples = random.sample(range(len(population)), sample_number)
        min_objective = float('inf')
        for j in samples:
            if fitnesses[j] < min_objective:
                min_index = j
                min_objective = fitnesses[j]
        newPopulation.append(population[min_index])
        newFitnesses.append(fitnesses[min_index])
    return newPopulation, newFitnesses


def select2(population, fitnesses):
    newPopulation = []
    newFitnesses = []

    # 精英选择
    best_index=fitnesses.index(min(fitnesses))
    best_individual=population[best_index]
    for i in range(int(0.1*len(population))): #10%
        newPopulation.append(best_individual)
        newFitnesses.append(min(fitnesses))

    # 扰动选择
    best_solution=one2many2(best_individual)
    for i in range(int(0.05*len(population))): #5%
        number = random.randrange(0, 3)
        current_solution = Pertur(best_solution).bestNeighbor(number)
        a, b, c, d,e = solution_fitness(current_solution)
        if a == float('inf'):
            current_solution = infeasibleRepair(current_solution)
            a, b, c, d,e = solution_fitness(current_solution)
        current_fitness=calFitness(a,b,c,d,e)
        current_individual=many2one2(current_solution)
        newPopulation.append(current_individual)
        newFitnesses.append(current_fitness)

    # 锦标赛选择
    for i in range(int(0.85*len(population))): #85%
        sample_number = random.randint(1, int(len(population) / 2) - 1)
        # sample_number=random.randint(1,len(population))
        samples = random.sample(range(len(population)), sample_number)
        min_objective = float('inf')
        for j in samples:
            if fitnesses[j] <= min_objective:
                min_index = j
                min_objective = fitnesses[j]
        newPopulation.append(population[min_index])
        newFitnesses.append(fitnesses[min_index])
    popA, popB, fitnessA, fitnessB = divide(newPopulation, newFitnesses)
    return popA, popB


def getNeighborList(population):
    neighborTable = np.zeros((customers_account, customers_account), dtype='int')
    for individual in population:
        solution = one2many2(individual)
        for route in solution:
            for i, j in zip(route[1:-2], route[2:-1]):
                neighborTable[i][j] += 1
    neighborList = np.zeros(customers_account, dtype='int')
    neighborList[0] = 0
    for i in range(1, len(neighborTable)):
        j = np.argmax(neighborTable[i])
        neighborList[i] = j
    return neighborList


def getLocationList(population):
    locationTable = np.zeros((131, 131), dtype='int')
    for individual in population:
        for i in range(len(individual)): # i 是位置
            j=individual[i] # i处的顾客是j
            locationTable[i][j]+=1
    locationList = np.zeros(131, dtype='int')
    for i in range(len(locationTable)):
        j = np.argmax(locationTable[i]) #索引
        locationList[i] = j
    return locationList



def crossover(popA, popB):  # 新的交叉方法
    population=popA+popB
    neighborList = getNeighborList(population)
    locationList=getLocationList(population)
    for i in range(0, len(popA) - 1, 2):
        rate = random.random()
        if rate >= pclA and rate <= pchA:
            parent1, parent2 = popA[i], popA[len(popA)-1-i]
            child1 = [0 for x in range(len(parent1))]
            child2 = [0 for x in range(len(parent2))]
            # 和neighborList中元素相同的进行复制
            for j in range(len(parent1[:-1])):
                m = parent1[j]
                if parent1[j] <= 100 and parent1[j + 1] <= 100 and parent1[j + 1] == neighborList[m]:
                    child1[j], child1[j + 1] = parent1[j], parent1[j + 1]
            for j in range(len(parent2[:-1])):
                m = parent2[j]
                if parent2[j] <= 100 and parent2[j + 1] <= 100 and parent2[j + 1] == neighborList[m]:
                    child2[j], child2[j + 1] = parent2[j], parent2[j + 1]
            # 和locationList中元素相同的进行复制
            for j in range(len(parent1)):
                if child1[j]==0 and parent1[j]==locationList[j]:
                    child1[j]=parent1[j]
            for j in range(len(parent2)):
                if child2[j]==0 and parent2[j]==locationList[j]:
                    child2[j]=parent2[j]
            # 补充剩余的元素

            diff2 = [x for x in parent2 if x not in child1]  # parent2-child1，这样可以用diff2的元素填充chi
            #child1中的0元素
            diff1 = [x for x in parent1 if x not in child2]  # parent1-child2，这样可以用diff1的元素填充child2中的0元素
            x = 0
            for j in range(len(child1)):
                if child1[j] == 0:
                    child1[j] = diff2[x]
                    x += 1
            y = 0
            for j in range(len(child2)):
                if child2[j] == 0:
                    child2[j] = diff1[y]
                    y += 1
            popA[i], popA[i + 1] = child1, child2
    for i in range(0, len(popB) - 1, 2):
        rate = random.random()
        if rate >= pclB and rate <= pchB:
            parent1, parent2 = popB[i], popB[len(popB)-1-i]
            child1 = [0 for x in range(len(parent1))]
            child2 = [0 for x in range(len(parent2))]
            for j in range(len(parent1[:-1])):
                m = parent1[j]
                if parent1[j] <= 100 and parent1[j + 1] <= 100 and parent1[j + 1] == neighborList[m]:
                    child1[j], child1[j + 1] = parent1[j], parent1[j + 1]
            for j in range(len(parent2[:-1])):
                m = parent2[j]
                if parent2[j] <= 100 and parent2[j + 1] <= 100 and parent2[j + 1] == neighborList[m]:
                    child2[j], child2[j + 1] = parent2[j], parent2[j + 1]
            diff2 = [x for x in parent2 if x not in child1]  # parent2-child1，这样可以用diff2的元素填充child1中的0元素
            diff1 = [x for x in parent1 if x not in child2]  # parent1-child2，这样可以用diff1的元素填充child2中的0元素
            p2c1_index, p1c2_index=int(len(diff2)/2), int(len(diff1)/2)
            diff2=diff2[p2c1_index:len(diff2)]+diff2[:p2c1_index]
            diff1=diff1[p1c2_index:len(diff1)]+diff1[:p1c2_index]
            x=0
            for j in range(len(child1)):
                if child1[j] == 0:
                    child1[j]=diff2[x]
                    x+=1
            y=0
            for j in range(len(child2)):
                if child2[j] == 0:
                    child2[j] = diff1[y]
                    y+=1
            popB[i], popB[i + 1] = child1, child2
    return popA, popB


def mutate(popA, popB, G_max, G):
    for i in range(len(popA)):
        lam = math.cos(math.pi / 2 * (G_max - G) / G_max)
        pm_now = pmA * math.e ** lam
        rate = random.random()
        if rate <= pm_now:
            p1, p2 = random.sample(range(len(popA[i])), 2)
            popA[i][p1], popA[i][p2] = popA[i][p2], popA[i][p1]
    for i in range(len(popB)):
        lam = math.cos(math.pi / 2 * (G_max - G) / G_max)
        pm_now = pmB * math.e ** lam
        rate = random.random()
        if rate <= pm_now:
            start, stop = sorted(random.sample(range(len(popB[i])), 2))
            popB[i] = popB[i][:start] + popB[i][start:stop][::-1] + popB[i][stop:]
    return popA, popB

# 计算列表中最小的N个数对应的索引
def get_list_min_index(list_, n):
    N_large = pd.DataFrame({'score': list_}).sort_values(by='score', ascending=[True])
    return list(N_large.index)[:n]

def divide(population, fitnesses):
    # 得到前一半小的适应度对应的索引
    min_list = get_list_min_index(fitnesses, int(len(fitnesses) / 2))
    # max_list=get_list_max_index(fitnesses,int(len(fitnesses)/2))
    popA, popB = [], []
    fitnessA,fitnessB=[], []
    for i in range(len(population)):
        if i in min_list:
            popA.append(population[i])
            fitnessA.append(fitnesses[i])
        else:
            popB.append(population[i])
            fitnessB.append(fitnesses[i])
    return popA, popB,fitnessA,fitnessB


def biPopulation(population, fitnesses):
    for solution, i in zip(population, range(len(population))):
        population[i] = many2one2(solution)
    best_fitness = float('inf')
    best_individual=[0,0,0,0,0,0,0,0,0,0]
    fitness_list2 = []
    fitness_list3 = []
    # population, fitnesses = select1(population, fitnesses)
    for i in range(100):  # 迭代100次！！！！！！！！！！！！！！！！！！！！！！！！！！！
        popA, popB = select2(population, fitnesses)
        popA, popB = crossover(popA, popB)
        popA, popB = mutate(popA, popB, G_max, i)
        population, fitnesses, min_individual, min_fitness = LNS(popA, popB)
        # fitness_list2.append(min_fitness)
        print(fitnesses)
        if min_fitness <= best_fitness:
            best_fitness = min_fitness
            best_individual = min_individual
        print('\n第', i, '代最优解：', min_fitness, min_individual)
        print('最优解：', best_fitness, best_individual)
        fitness_list2.append(best_fitness)
        # fitness_list3.append(min_fitness)

    solution = one2many2(best_individual)
    print('目标值为：', best_fitness)
    title = 'HTS'
    # print('best200',fitness_list)
    # print('best100',fitness_list2)
    # print('min200',min200)
    # print('min100', fitness_list3)
    plotLines(fitness_list2, title, 'fitness')
    plotRoutes(solution)
    return best_fitness, solution


def ILSbiPopulation(population, fitnesses):
    for solution, i in zip(population, range(len(population))):
        population[i] = many2one2(solution)
    best_fitness = float('inf')
    best_individual=[0,0,0,0,0,0,0,0,0,0]
    best_solution=[0,0,0]
    fitness_list2 = []
    # population, fitnesses = select1(population, fitnesses)
    for i in range(100):  # 迭代100次！！！！！！！！！！！！！！！！！！！！！！！！！！！
        popA, popB = select2(population, fitnesses)
        popA, popB = crossover(popA, popB)
        popA, popB = mutate(popA, popB, G_max, i)
        population, fitnesses, min_solution, min_fitness = iterLS2(popA, popB)
        # fitness_list2.append(min_fitness)
        # print(fitnesses)
        if min_fitness <= best_fitness:
            best_fitness = min_fitness
            best_solution=min_solution

        print('\n第', i, '代最优解：', min_fitness, min_solution)
        print('最优解：', best_fitness, best_solution)
        fitness_list2.append(best_fitness)

    print('目标值为：', best_fitness)
    title = 'BPMA'
    plotLines(fitness_list2, title, 'fitness')
    plotRoutes(best_solution)
    return best_solution, best_fitness, fitness_list2

# ！！！！！！！！！！！！！！！！！！！！！！
# 修改了ILS文件iterLS2函数的localSearch2为localSearch4！！！！！！！！！！！
# ！！！！！！！！！！！！！！！！！！！！！！
if __name__ == '__main__':
    f1 = open(file, 'a', newline='')
    csv_writer1 = csv.writer(f1)
    for i in range(4):
        print('第',i,'次迭代')
        algorithm = '非TS种群解'
        population, fitnesses, vehicleses = initial_solution(algorithm)
        print('*******************双种群*********************')
        start = time.time()
        solution, fitness, fitness_list2 = ILSbiPopulation(population, fitnesses)
        end = time.time()
        print()
        print(globalPath)
        a, b, c, d, e = solution_fitness(solution)
        f = calFitness(a, b, c, d, e)
        print('BiPopulation')
        print(file)
        print('%s' % (end - start), fitness, a, b, c, d,e)
        csv_writer1.writerow([globalPath,(end-start),fitness,a,b,c,d,e,fitness_list2, solution])
    f1.close()

