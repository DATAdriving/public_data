from structure import *
import random
from plotData import *
import numpy as np
from structure import *
from utils import *
from AIA_utils import *
from VNS import *
from tabu_search import *
import csv
from perturbation import *
from LNS import *


def reorganization(customers,vehicleNo): #对不可行的路径按照时间进行排序重组
    def sorted_readytime(customers):  # 按照ready_time进行排序
        return list(sorted(customers, key=lambda customer: customer.ready_time))
    customers = sorted_readytime(customers)
    for customer in customers:
        customer.is_serviced=False
    def get_available_customers(customers):  # 还未访问过的顾客
        return list(filter(lambda customer: not customer.is_serviced, customers))
    customers = get_available_customers(customers)
    solution = []
    # vehicleNo=0
    while len(customers) > 0:  # 还有未访问过的顾客时进行循环
        vehicleNow = Vehicle(vehicleNo)
        vehicleNow.setCapacity()
        vehicleNow.route=[depot.number]
        continue_count=0

        last_customer = depot.number
        for customer in customers:  # 确定每一条路径的customer
            distance_depot = customer_distance_mat[customer.number][depot.number]
            start_service_time = max(customer.ready_time, vehicleNow.time + customer_distance_mat[last_customer][customer.number])
            time_temp = start_service_time + customer.service_time + distance_depot
            capacity_temp_sum = 0
            deliCapa_temp_sum = 0
            capacity_temp = np.zeros(len(vehicleNow.capacity), dtype=int)
            deliCapa_temp = np.zeros(len(vehicleNow.deliCapa), dtype=int)

            for i in range(len(vehicleNow.capacity)):
                capacity_temp[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
                capacity_temp_sum += capacity_temp[i]  # 如果总重量超过最大承载能力，换下一个顾客
                deliCapa_temp[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
                deliCapa_temp_sum += deliCapa_temp[i]  # 如果车上没有从仓库运来的物品了，换车

            if time_temp > depot.due_time or deliCapa_temp_sum < 0 or continue_count > 2:  # 换车
                break
            elif continue_count < 3 and (capacity_temp_sum > vehicleNow.vehicle_capacity or min(deliCapa_temp) < 0):  # 换下一个顾客
                continue_count += 1
                continue
            else:
                vehicleNow.time, vehicleNow.capacity, vehicleNow.deliCapa = time_temp - distance_depot, capacity_temp, deliCapa_temp
                customer.pickup_request = [0,0,0,0,0]
                customer.delivery_request = [0,0,0,0,0]
                customer.is_serviced = True
                vehicleNow.route.append(customer.number)
            last_customer = customer.number
        vehicleNow.route.append(depot.number)
        solution.append(vehicleNow.route)
        customers = get_available_customers(customers)
        vehicleNo+=1 #这样就能保证接下来的路径是重型卡车了!!!!!!
    return solution


def infeasibleRepair(solution):
    # solution=one2many2(individual)
    newSolution=list(solution)
    for route, vehicleNo in zip(solution, range(len(solution))):  # 对每条路径计算适应度
        is_feasible, routeDistance, routeFuelConsumpt, routePunish = route_fitness(route, vehicleNo)
        if is_feasible == False:
            customers=[]
            for cus in route[1:-1]:
                for x in global_customers:
                    if cus==x.number:
                        customer=x
                        customers.append(customer)
            small_solution=reorganization(customers,vehicleNo)
            # newSolution.remove(route)
            newSolution[vehicleNo] = small_solution[0]
            for small_route in small_solution[1:]:
                newSolution.append(small_route)
    # individual=many2one2(newSolution)
    return newSolution


def becomeFeasiblePop(popA,popB):
    population = popA + popB
    fitnesses = []
    for individual, j in zip(population, range(len(population))):
        # print('第几个个体', j)
        solution = one2many2(individual)
        a, b, c, d, e = solution_fitness(solution)
        if a == float('inf'): # 解不可行
            solution = infeasibleRepair(solution)
            population[j]=many2one2(solution)
            a, b, c, d, e= solution_fitness(solution)
        fit = calFitness(a, b, c, d, e)
        fitnesses.append(fit)
    return population,fitnesses



def traverseSearch(solution,fitness):
    a,b,c,d,e=solution_fitness(solution)
    fit=[a,b,c,d,e]
    Best_fitness=fitness
    BestC, BestC_R, BestC_P, BestR, BestP=0,0,0,0,0 #为了最后保证找到一个可行的变化方式

    for i in range(len(solution)):  # i也就是vehicle_No
        routei = solution[i]
        routei_oldFit = route_fitness(routei, i)
        for j in range(1,len(routei)-1):  # j代表顾客在路径中的位置，也就是P
            # if routei[j] != 0:
            number = routei.pop(j)
            routei_newFit = route_fitness(routei, i)
            # 接下来对部分可插入位置进行
            geshu=random.randint(0,int(len(solution)/2))
            solution_lengh = [i for i in range(len(solution))]
            routes=random.sample(solution_lengh, geshu) # 选择几个不同的数QW23
            for m in routes:
            # for m in range(len(solution)):
                routem = solution[m]
                routem_oldFit = route_fitness(routem, m)
                for n in range(1, len(routem)):
                    routem.insert(n, number)
                    routem_newFit = route_fitness(routem, m)
                    temp_fitness = change_fitness(fit, routei_oldFit, routei_newFit, routem_oldFit, routem_newFit)
                    if temp_fitness < Best_fitness:
                        print('Traverse: temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
                        BestC, BestC_R, BestC_P, BestR, BestP = number, i, j, m, n
                        Best_fitness = temp_fitness
                    routem.pop(n)
            routei.insert(j, number)
    if BestC != 0:
        print('BestC,BestC_R,BestC_P,BestR,BestP', BestC, BestC_R, BestC_P, BestR, BestP)
        customer = solution[BestC_R].pop(BestC_P)
        solution[BestR].insert(BestP, customer)
    return solution,Best_fitness


def localSearch(solution,fitness):
    x=random.randint(0,2)
    if x==0:
        solution, fitness=ILSLNS(solution,fitness)
        # solution,fitness=traverseSearch(solution,fitness)
        Tlist.append(fitness)
    elif x==1:
        solution, fitness=ILSLNS(solution,fitness)
        Llist.append(fitness)
    else:
        solution, fitness=ILSLNS(solution,fitness)
        # solution, fitness=VNS_implement2(solution,fitness)
        Vlist.append(fitness)
    return solution, fitness


fun_dict={
    traverseSearch: Tlist,
    ILSLNS: Llist,
    VNS_implement2: Vlist,
}

# def useTraverse(solution,fitness):


def localSearch2(solution,fitness):
    # 如果每种方法都用过了
    # 如果直接选择最好的，就会导致只用第一种。不过再想想后期应该也会用别的
    Tvalue=0.7*Tlist[-1]+0.3*ave(Tlist[:-1])
    Lvalue=0.7*Llist[-1]+0.3*ave(Llist[:-1])
    Vvalue=0.7*Vlist[-1]+0.3*ave(Vlist[:-1])
    # LNS
    if Lvalue>=Tvalue and Lvalue>=Vvalue:
        rate = random.random()
        if rate > 0.2:
            solution2, fitness2 = ILSLNS(solution, fitness)
            Llist.append(fitness - fitness2)
        else:
            funs = [traverseSearch, VNS_implement2]
            fun = random.choice(funs)
            solution2, fitness2 = fun(solution, fitness)
            list = fun_dict[fun]
            list.append(fitness - fitness2)
    # traverse
    elif Tvalue >= Lvalue and Tvalue >= Vvalue:
        rate = random.random()
        if rate > 0.3:
            solution2, fitness2 = traverseSearch(solution, fitness)
            Tlist.append(fitness-fitness2)
        else:
            funs=[ILSLNS,VNS_implement2]
            fun=random.choice(funs)
            solution2, fitness2 = fun(solution, fitness)
            list=fun_dict[fun]
            list.append(fitness-fitness2)
    # VNS
    else:
        rate = random.random()
        if rate > 0.7:
            solution2, fitness2 = VNS_implement2(solution, fitness)
            Vlist.append(fitness - fitness2)
        else:
            funs = [traverseSearch, ILSLNS]
            fun = random.choice(funs)
            solution2, fitness2 = fun(solution, fitness)
            list = fun_dict[fun]
            list.append(fitness - fitness2)
    return solution2,fitness2


def localSearch3(solution,fitness):
    rate = random.random()
    if rate > 0.3:
        solution2, fitness2 = ILSLNS(solution, fitness)
    else:
        funs = [traverseSearch, VNS_implement2]
        fun = random.choice(funs)
        solution2, fitness2 = fun(solution, fitness)
    return solution2,fitness2


def localSearch4(solution,fitness):
    solution2, fitness2 = Tabu_Search(solution, fitness)
    # funs = [traverseSearch, ILSLNS, VNS_implement2]
    # fun = random.choice(funs)
    # solution2, fitness2 = fun(solution, fitness)
    return solution2,fitness2

def ave(l):
    sum = 0
    for x in l:
        sum = sum + x
    ave = sum/len(l)
    return ave


def perturbation(best_solution):
    number=random.randrange(0,5)
    current_solution=Pertur(best_solution).bestNeighbor(number)
    a,b,c,d,e=solution_fitness(current_solution)
    if a==float('inf'):
        current_solution = infeasibleRepair(current_solution)
    return current_solution


def iterLS(popA,popB):
    population, fitnesses=becomeFeasiblePop(popA,popB)
    index=fitnesses.index(min(fitnesses)) #找到fitness最小的个体的索引
    solution=one2many2(population[index])
    best_solution,best_fitness = localSearch(solution,min(fitnesses))
    # 接下来对solution进行迭代局部搜索
    for i in range(10):# 进行10次
        current_solution=perturbation(best_solution)
        a,b,c,d,e=solution_fitness(current_solution)
        current_fitness=calFitness(a,b,c,d,e)
        current_solution,current_fitness = localSearch(current_solution,current_fitness)
        if current_fitness<best_fitness:
            best_fitness=current_fitness
            best_solution=current_solution
    one=many2one2(best_solution)
    population[index] =one
    fitnesses[index]=best_fitness
    min_index = fitnesses.index(min(fitnesses))
    min_individual = population[min_index]
    return population,fitnesses,min_individual,min(fitnesses)


def iterLS2(popA,popB):
    population, fitnesses=becomeFeasiblePop(popA,popB)
    index=fitnesses.index(min(fitnesses)) #找到fitness最小的个体的索引
    best_fitness=min(fitnesses)
    best_solution=one2many2(population[index])
    # 接下来对solution进行迭代局部搜索
    # 得到的best_solution会有[0,0]的情况
    best_solution,best_fitness = localSearch4(best_solution,best_fitness)
    # best_solution, best_fitness = traverseSearch(best_solution, best_fitness) # 单独使用traverse
    # best_solution, best_fitness = ILSLNS(best_solution, best_fitness) # 单独使用LNS
    # best_solution, best_fitness = VNS_implement2(best_solution, best_fitness) # 单独使用VNS
    one=many2one2(best_solution)
    population[index] =one
    fitnesses[index]=best_fitness
    # 经验证，最小的fitness就是best_fitness
    return population,fitnesses,best_solution,best_fitness



