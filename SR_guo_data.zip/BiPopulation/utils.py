from plotData import *


def sorted_criterion(customers,a, b):  # 按照ready_time进行排序，默认升序排序
    return list(sorted(customers, key=lambda customer: a * customer.ready_time + b * (customer.pickup_sum - customer.delivery_sum)))
def get_available_customers(customers): #还未访问过的顾客
    return list(filter(lambda customer: not customer.is_serviced, customers))


'''
输出解
'''
def print_solution(solution):
    for route, i in zip(solution, range(len(solution))):
        print('No'+str(i), end=' ')
        for number in route:
            print(number, end=' ')
        print()


def calFitness(small_vehicleNumber,large_vehicleNumber,distance,fuelConsumption,punish):
    fitness=10*small_vehicleNumber+15*large_vehicleNumber+distance+fuelConsumption+punish
    return fitness

def change_fitness(Fit, i_oldFit, i_newFit, m_oldFit, m_newFit):
    if m_newFit[0] == False or i_newFit[0] == False:
        solutionFit = float('inf')
    else:
        solutionDistance = Fit[2] - i_oldFit[1] - m_oldFit[1] + i_newFit[1] + m_newFit[1]
        solutionoverLoad=Fit[3] - i_oldFit[2] - m_oldFit[2] + i_newFit[2] + m_newFit[2]
        solutionPunish = Fit[4] - i_oldFit[3] - m_oldFit[3] + i_newFit[3] + m_newFit[3]
        solutionFit=calFitness(Fit[0],Fit[1],solutionDistance,solutionoverLoad,solutionPunish)
    return solutionFit


def inRoute_fitness(solutionFit, i_oldFit, i_newFit):
    if i_newFit[0] == False:
        solutionFit = float('inf')
    else:
        solutionDistance = - i_oldFit[1] + i_newFit[1]
        solutionoverLoad =  - i_oldFit[2] + i_newFit[2]
        solutionPunish =  - i_oldFit[3]+ i_newFit[3]
        solutionFit = solutionFit+solutionDistance+solutionoverLoad+solutionPunish
    return solutionFit


def outRoute_fitness(solutionFit, i_oldFit, i_newFit, m_oldFit, m_newFit):
    if m_newFit[0] == False or i_newFit[0] == False:
        solutionFit = float('inf')
    else:
        solutionDistance = - i_oldFit[1] - m_oldFit[1] + i_newFit[1] + m_newFit[1]
        solutionoverLoad = - i_oldFit[2] - m_oldFit[2] + i_newFit[2] + m_newFit[2]
        solutionPunish = - i_oldFit[3] - m_oldFit[3] + i_newFit[3] + m_newFit[3]
        solutionFit = solutionFit + solutionDistance + solutionoverLoad + solutionPunish
    return solutionFit


def solution_fitness(solution):
    small_vehicleNumber=0
    large_vehicleNumber=0
    # vehicleNumber=len(solution)
    solutionDistance = 0
    solutionFuelConsumpt = 0
    solutionPunish = 0
    for route, vehicleNo in zip(solution, range(len(solution))):  # 对每条路径计算适应度
        # is_feasible, distance, punish = TS_route_fitness(route, vehicleNo)
        is_feasible, routeDistance, routeFuelConsumpt, routePunish = route_fitness(route, vehicleNo)
        if is_feasible == False:
            # print('该路径不可行')
            return float('inf'), float('inf'), float('inf'), float('inf'), float('inf')
        else:
            solutionDistance += routeDistance
            solutionFuelConsumpt += routeFuelConsumpt
            solutionPunish += routePunish
        if vehicleNo<10 and len(route)>2:
            small_vehicleNumber+=1
        elif vehicleNo>=10 and len(route)>2:
            large_vehicleNumber+=1
    return small_vehicleNumber,large_vehicleNumber, solutionDistance, solutionFuelConsumpt, solutionPunish

# def solution_fitness(solution):
#     vehicle_number = len(solution)
#     # solutionFit = 0
#     solutionDistance = 0
#     solutionoverLoad=0
#     solutionPunish = 0
#     for route, vehicleNo in zip(solution, range(len(solution))):  # 对每条路径计算适应度
#         # is_feasible,routeFit=route_fitness(route,vehicleNo)
#         is_feasible, routeDistance, routeoverLoad, routePunish = route_fitness(route, vehicleNo)
#         if is_feasible == False:
#             print('该路径不可行\n')
#             return float('inf'), float('inf'), float('inf'), float('inf')
#             break
#         else:
#             solutionDistance += routeDistance
#             solutionoverLoad += routeoverLoad
#             solutionPunish += routePunish
#     return vehicle_number, solutionDistance, solutionoverLoad, solutionPunish

def route_fitness(route, vehicleNo):  # 第几辆车
    if len(route)==2:
        return True,0,0,0
    vehicleNow = Vehicle(vehicleNo)
    vehicleNow.setCapacity()
    vehicleNow.time = 0
    is_feasible = True
    last_number=depot.number
    for number in route[1:-1]:
        capacity_sum=sum(vehicleNow.capacity)
        #0.0981*100
        vehicleNow.fuelConsumption+=customer_distance_mat[last_number][number]*(9.81*(vehicleNow.deadWeight+capacity_sum)+0.6465*vehicleNow.speed*vehicleNow.speed)/42600
        for i in global_customers:
            if i.number == number:
                customer = i
        # if vehicleNow.time < customer.ready_time:  # 开始时间在时间窗之内，否则进行惩罚
        #     vehicleNow.punish += customer.ready_time - vehicleNow.time
        vehicleNow.distance+=customer_distance_mat[last_number][number]
        last_distance = customer_distance_mat[last_number][number]
        start_service_time = max(vehicleNow.time+last_distance, customer.ready_time)
        if start_service_time > customer.due_time:
            vehicleNow.punish += start_service_time - customer.due_time
            # vehicleNow.punish += vehicleNow.time - customer.due_time
        vehicleNow.time = start_service_time + customer.service_time
        temp_time=vehicleNow.time+customer_distance_mat[number][depot.number]
        capacity_sum = 0
        deliCapa_sum = 0
        ########这里的capacity不知道是不是最开始的，是
        for i in range(len(vehicleNow.capacity)): #计算重量
            vehicleNow.capacity[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
            capacity_sum += vehicleNow.capacity[i]  # 如果总重量超过最大承载能力，换下一个顾客
            vehicleNow.deliCapa[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
            deliCapa_sum += vehicleNow.deliCapa[i]  # 如果车上没有从仓库运来的物品了，换车
        if capacity_sum>vehicleNow.vehicle_capacity or min(vehicleNow.deliCapa) < 0 or temp_time > depot.due_time:  # 换车，不允许超载，不允许
            is_feasible, vehicleNow.distance, vehicleNow.fuelConsumption, vehicleNow.punish = False, float('inf'), float('inf'), float('inf')
            break
        last_number=number
    vehicleNow.distance += customer_distance_mat[number][depot.number]
    vehicleNow.fuelConsumption+=customer_distance_mat[last_number][depot.number]*(9.81*(vehicleNow.deadWeight+capacity_sum)+0.6465*vehicleNow.speed*vehicleNow.speed)/42600
    vehicleNow.time += customer_distance_mat[number][depot.number]
    # vehicleNow.fuelConsumption=0 #设置油耗为0呢
    # vehicleNow.distance=0 #设置距离和时间惩罚为0
    # vehicleNow.punish=0
    return is_feasible, vehicleNow.distance,vehicleNow.fuelConsumption,vehicleNow.punish



