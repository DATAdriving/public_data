


alphas = 1 # learning rate
gammas = 0.1  # discount rate
epsilons = 0.9  # epsilon for e-greedy policy
epsilon_decays = 0.001  # epsilon decay after every epoch
sampling_sampling_runs = 10


# R表（也就是reward表用 使用完局部搜索策略后的fitness差值的负数）
# Q表一开始都为0
# 目前的问题在于并不是所有的状态都能表示出来的
# 让0代表动作traverse，1代表LNS，2代表VNS


def Qlearning(solution):
    s=solution
    R=100
