from VNS import *
from AIA_utils import *
from LNS import *
import time
import math
import csv

pcl=0.6 # 交叉概率
pch=0.95 # 交叉概率
pm=0.15 # 变异概率

selectNumber=10

# 锦标赛选择
def tournamentSelect(population,fitnesses):
    fitness, density = calDensity(population, fitnesses)
    weightPro = np.zeros(len(population))
    for i in range(len(population)):
        weightPro[i] = fitness[i] + density[i]
    newPopulation=[]
    newFitnesses=[]

    for i in range(selectNumber):
        sample_number=random.randint(1,int(len(population)/2)-1)
        # sample_number=random.randint(1,len(population))
        samples=random.sample(range(len(population)),sample_number)
        min_objective=float('inf')
        for j in samples:
            if fitnesses[j]<min_objective:
                min_index=j
                min_objective=fitnesses[j]
        newPopulation.append(population[min_index])
        newFitnesses.append(fitnesses[min_index])
    return newPopulation


def getNeighborList(parents):
    neighborTable=np.zeros((customers_account,customers_account),dtype='int')
    for individual in parents:
        solution=one2many2(individual)
        for route in solution:
            for i,j in zip(route[1:-2],route[2:-1]):
                neighborTable[i][j]+=1
    neighborList=np.zeros(customers_account,dtype='int')
    neighborList[0]=0
    for i in range(1,len(neighborTable)):
        j=np.argmax(neighborTable[i])
        neighborList[i]=j
    return neighborList


def crossover(parents): # 新的交叉方法，但是如果使用这种方法，那么解的修复方法应该是也要更改
    neighborList=getNeighborList(parents)
    for i in range(0,len(parents)-1,2):
        rate=random.random()
        if rate>=pcl and rate<=pch:
            parent1,parent2=parents[i],parents[i+1]
            child1=[0 for x in range(len(parent1))]
            child2=[0 for x in range(len(parent2))]
            for j in range(len(parent1[:-1])):
                m=parent1[j]
                if parent1[j]<=100 and parent1[j+1]<=100 and parent1[j+1]==neighborList[m]:
                    child1[j],child1[j+1]=parent1[j],parent1[j+1]
            for j in range(len(parent2[:-1])):
                m=parent2[j]
                if parent2[j]<=100 and parent2[j+1]<=100 and parent2[j+1]==neighborList[m]:
                    child2[j],child2[j+1]=parent2[j],parent2[j+1]
            diff2=[x for x in parent2 if x not in child1] # parent2-child1，这样可以用diff2的元素填充child1中的0元素
            diff1=[x for x in parent1 if x not in child2] # parent1-child2，这样可以用diff1的元素填充child2中的0元素
            for j in range(len(child1)):
                if child1[j]==0:
                    child1[j]=diff2.pop()
            for j in range(len(child2)):
                if child2[j]==0:
                    child2[j]=diff1.pop()
            parents[i],parents[i+1]=child1,child2
    return parents



def mutate(parents,G_max,G):
    for i in range(len(parents)):
        lam=math.cos(math.pi/2*(G_max-G)/G_max)
        pm_now=pm*math.e**lam
        rate = random.random()
        if rate <= pm_now:
            start, stop = sorted(random.sample(range(len(parents[i])), 2))
            parents[i] = parents[i][:start] + parents[i][start:stop][::-1] + parents[i][stop:]
    return parents


"""
计算列表中最小的N个数对应的索引
"""
def get_list_min_index(list_, n):
    N_large = pd.DataFrame({'score': list_}).sort_values(by='score', ascending=[True])
    return list(N_large.index)[:n]
def get_list_max_index(list_, n):
    N_large = pd.DataFrame({'score': list_}).sort_values(by='score', ascending=[False])
    return list(N_large.index)[:n]



def divide(population,fitnesses):
    # 得到前一半小的适应度对应的索引
    min_list=get_list_min_index(fitnesses,int(len(fitnesses)/2))
    # max_list=get_list_max_index(fitnesses,int(len(fitnesses)/2))
    popA, popB=[],[]
    for i in range(len(population)):
        if i in min_list:
            popA.append(population[i])
        else:
            popB.append(population[i])
    return popA, popB

def LNS(population):
    # population=popA+ popB
    for ii in range(1):
        fitnesses=[]
        for individual, j in zip(population, range(len(population))):
            # print('第几个个体', j)
            solution = one2many2(individual)
            a,b,c,d=solution_fitness(solution)
            fit=calFitness(a,b,c,d)
            if fit!=float('inf'):
                original_solution=list(solution)
                if len(solution)>24:
                    print('LNS用到了消除路径')
                    solution=Eliminates_Route(solution)
                solution, removed= destroy(solution)
                solution, fitness = repair(fit,original_solution,solution, removed)
                fitnesses.append(fitness)
            else: #先修复不可行解
                population[j],newSolution=infeasibleRepair(individual)
                a,b,c,d=solution_fitness(newSolution)
                fit=calFitness(a,b,c,d)
                original_solution = list(newSolution)
                if len(newSolution)>24:
                    print('LNS用到了消除路径')
                    newSolution=Eliminates_Route(newSolution)
                solution, removed = destroy(newSolution)
                solution, fitness = repair(fit,original_solution,solution, removed)
                # solution, fitness = VNS_implement(solution)
                # print('最开始是不可行解',fitness)
                fitnesses.append(fitness)
            population[j] = many2one2(solution)
    min_index=fitnesses.index(min(fitnesses))
    min_individual=population[min_index]
    return population,fitnesses,min_individual,min(fitnesses)


def HTS(population,fitnesses):
    for solution, i in zip(population, range(len(population))):
        population[i] = many2one2(solution)
    best_fitness = float('inf')
    fitness_list2 = []
    fitness_list3 = []
    for i in range(100):  # 迭代100次！！！！！！！！！！！！！！！！！！！！！！！！！！！
        population=tournamentSelect(population, fitnesses)
        population = crossover(population)
        population = mutate(population,G_max,i)
        population, fitnesses, min_individual, min_fitness = LNS(population)
        # fitness_list2.append(min_fitness)
        print(fitnesses)
        if min_fitness <= best_fitness:
            best_fitness = min_fitness
            best_individual = min_individual
        print('\n第', i, '代最优解：', min_fitness, min_individual)
        print('最优解：', best_fitness, best_individual)
        fitness_list2.append(best_fitness)
        # fitness_list3.append(min_fitness)

    solution = one2many2(best_individual)
    print('目标值为：', best_fitness)
    title = 'HTS'
    # print('best200',fitness_list)
    # print('best100',fitness_list2)
    # print('min200',min200)
    # print('min100', fitness_list3)
    plotLines(fitness_list2, title, 'fitness')
    plotRoutes(solution)
    return best_fitness, solution


if __name__ == '__main__':
    # f1 = open('HTS_dprc201.csv', 'a', newline='')
    # csv_writer1 = csv.writer(f1)
    # csv_writer1.writerow(
    #     ['fileName', 'time', 'fitness', 'DptrDate', 'DptrTime', 'DptrStn', 'ArrvDate', 'ArrvTime', 'ArrvStn', 'Nature'])
    for i in range(1):
        algorithm='qita'
        start=time.time()
        population,fitnesses = initial_solution(algorithm)
        print('*******************单种群*********************')
        fitness,solution=HTS(population[:10],fitnesses[:10])
        end=time.time()
        print()
        print(globalPath)
        a, b, c, d = solution_fitness(solution)
        f=calFitness(a,b,c,d)
        print('%s' %(end-start),fitness,a, b, c, d)
    #     csv_writer1.writerow([globalPath,(end-start),fitness,a, b, c, d])
    # f1.close()

