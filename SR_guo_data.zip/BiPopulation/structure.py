import numpy as np
import time

'''
将txt文件转化为problem
'''
def get_customers(problem_file):
    with open(problem_file, 'r') as f:
        lines = list(map(lambda l: l.replace('\n', '').split(), f.readlines()))  # 映射!!!!!
        #print(lines)
        filename = lines[0][0]
        vehicle_number, vehicle_capacity = list(map(int, lines[4]))
        customers = []
        for line in lines[8:]:
            customers.append(Customer(*list(map(int, line))))  #
    return filename,customers,vehicle_number,vehicle_capacity
    # return Problem(filename, customers, vehicle_number, vehicle_capacity)


# 计算各个customer之间的距离矩阵
def calculate_dist_mat(customers):
    length = len(customers)
    customer_distance_mat = np.zeros((length, length))
    for i in range(length):
        customer_distance_mat[i][i] = float("inf")
        for j in range(i + 1, length):
            customer_distance_mat[i][j] = calculate_distance(customers[i], customers[j])
            customer_distance_mat[j][i] = customer_distance_mat[i][j]
    return customer_distance_mat

# 两个顾客之间求距离
def calculate_distance(customer1, customer2):
    return np.linalg.norm((customer1.x - customer2.x, customer1.y - customer2.y))


def loadCoordenates():
    coordenates=np.zeros((customers_account,2),dtype=float)
    for customer,i in zip(global_customers,range(len(global_customers))):
        coordenates[i][0]=customer.x
        coordenates[i][1]=customer.y
    return coordenates



class Customer:
    def __init__(self, number, x, y, ready_time, due_time, service_time, pickup0,delivery0, pickup1,delivery1,pickup2,delivery2,pickup3,delivery3,pickup4,delivery4):
        self.number = number
        self.x = x
        self.y = y
        self.ready_time = ready_time
        self.due_time = due_time
        self.service_time = service_time

        self.pickup = []
        self.pickup.append(pickup0)
        self.pickup.append(pickup1)
        self.pickup.append(pickup2)
        self.pickup.append(pickup3)
        self.pickup.append(pickup4)
        self.delivery = []
        self.delivery.append(delivery0)
        self.delivery.append(delivery1)
        self.delivery.append(delivery2)
        self.delivery.append(delivery3)
        self.delivery.append(delivery4)
        self.pickup_sum=0
        for i in range(len(self.pickup)):
            self.pickup_sum += self.pickup[i]
        self.delivery_sum=0
        for i in range(len(self.delivery)):
            self.delivery_sum += self.delivery[i]
        self.is_serviced = False
        self.route=None
        self.position=None


class Vehicle:
    def __init__(self,vehicleNo):
        self.vehicleNo=vehicleNo
        self.route = []
        self.capacity=np.array([0,0,0,0,0]) #40*5=200
        self.deliCapa=np.array([0,0,0,0,0])
        # self.capacity = np.array([38,38,38,38,38])
        # self.deliCapa = np.array([38,38,38,38,38])
        # self.capacity = np.array([40,40,40,40,40])
        # self.deliCapa = np.array([40,40,40,40,40])
        self.time=0
        self.punish = 0  #单条路径违反各节点时间窗约束时长总和
        self.distance = 0   #单条路径总长度
        self.overLoad = 0 #超载部分
        self.vehicle_capacity=0 ##########车辆的最大载重
        self.fuelConsumption=0 #油耗量
        self.deadWeight=0
        self.speed=35

    def setCapacity(self):
        if self.vehicleNo<10:
            self.capacity = np.array([19, 19, 19, 19, 19])  # 20*5=100
            self.deliCapa = np.array([19, 19, 19, 19, 19])
            self.vehicle_capacity = 100
            self.deadWeight=50
        else:
            self.capacity = np.array([39, 39, 39, 39, 39])  # 40*5=200
            self.deliCapa = np.array([39, 39, 39, 39, 39])
            self.vehicle_capacity = 200
            self.deadWeight=100

class individual:
    def __init__(self,solution:list):
        self.fitness=0


# 全局变量
globalPath = './data/dprc105.txt'
file = './results/verify_ILS2/50-BP_dprc105.csv'
# globalPath = './data/dpr205.txt'
# file = './results/verify_ILS/100-BP_dpr205.csv'
filename,global_customers,vehicle_number,vehicle_capacity = get_customers(globalPath)
customers_account = len(global_customers)
# vehicle_capacity_init = 180  #
depot: Customer = list(filter(lambda x: x.number == 0, global_customers))[0]
depot.is_serviced = True
customer_distance_mat = calculate_dist_mat(global_customers)
G_max=100
Iter_Max=10
Alpha = 1
Beta = 1
Sita = 0.1
popNumber=30
optNumber=5
tournamentNumber=25
rouletteWheelNumber=25
Tlist,Llist,Vlist=[0,0],[0,0],[0,0]

Tabu=np.zeros([len(global_customers),vehicle_number],dtype=int)
TabuCreate=np.zeros(len(global_customers),dtype=int)
Tabu_tenure=20







