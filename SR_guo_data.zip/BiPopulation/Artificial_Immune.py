from VNS import *
from AIA_utils import *
from LNS import *
import time

pcl=0.6 # 交叉概率
pch=0.95 # 交叉概率
pm=0.4 # 变异概率

# popNumber=30
optNumber=2
tournamentNumber=6 #只用了这个
rouletteWheelNumber=24

# 锦标赛选择
def tournamentSelection(population,fitnesses):
    fitness, density = calDensity(population, fitnesses)
    weightPro = np.zeros(len(population))
    for i in range(len(population)):
        weightPro[i] = fitness[i] + density[i]
    # 先选出来一个最好的初始解
    # min_index=weightPro.index(min(weightPro))
    min_index = np.argmin(weightPro)
    best_individual = population[min_index]
    newPopulation = [best_individual for i in range(optNumber)]
    # newPopulation=[]

    for i in range(tournamentNumber):
        sample_number=random.randint(1,len(population)/2)
        samples=random.sample(range(len(population)),sample_number)
        min_objective=float('inf')
        for j in samples:
            if fitnesses[j]<min_objective:
                min_index=j
                min_objective=fitnesses[j]
        newPopulation.append(population[min_index])
    return newPopulation


def getNeighborList(parents):
    neighborTable=np.zeros((customers_account,customers_account),dtype='int')
    for individual in parents:
        solution=one2many2(individual)
        for route in solution:
            for i,j in zip(route[1:-2],route[2:-1]):
                neighborTable[i][j]+=1
    neighborList=np.zeros(customers_account,dtype='int')
    neighborList[0]=0
    for i in range(1,len(neighborTable)):
        j=np.argmax(neighborTable[i])
        neighborList[i]=j
    return neighborList



def crossover4(parents): # 新的交叉方法，但是如果使用这种方法，那么解的修复方法应该是也要更改
    neighborList=getNeighborList(parents)
    for i in range(0,len(parents)-1,2):
        rate=random.random()
        if rate>=pcl and rate <=pch:
            parent1,parent2=parents[i],parents[i+1]
            child1=[0 for x in range(len(parent1))]
            child2=[0 for x in range(len(parent2))]
            for j in range(len(parent1[:-1])):
                m=parent1[j]
                if parent1[j]<=100 and parent1[j+1]<=100 and parent1[j+1]==neighborList[m]:
                    child1[j],child1[j+1]=parent1[j],parent1[j+1]
            for j in range(len(parent2[:-1])):
                m=parent2[j]
                if parent2[j]<=100 and parent2[j+1]<=100 and parent2[j+1]==neighborList[m]:
                    child2[j],child2[j+1]=parent2[j],parent2[j+1]
            diff2=[x for x in parent2 if x not in child1]
            diff1=[x for x in parent1 if x not in child2]
            for j in range(len(child1)):
                if child1[j]==0:
                    child1[j]=diff2.pop()
            for j in range(len(child2)):
                if child2[j]==0:
                    child2[j]=diff1.pop()
            parents[i],parents[i+1]=child1,child2
    return parents



def crossover3(parents): # 保留了原个体和新个体的种群，可行！ 来自2021本科生和能用-py-ga-VRPTW-master
    for i in range(0,len(parents),2):
        rate=random.random()
        if rate>=pcl and rate <=pch:
            parent1,parent2=parents[i],parents[i+1]
            # point1到point2
            res = random.sample(range(min(len(parent1), len(parent2))), 2)
            point1, point2 = res[0], res[1]
            if point2 < point1:
                point2, point1 = point1, point2
            child1 = parent2[point1:point2] + parent1
            child2 = parent1[point1:point2] + parent2
            # 消除第二次重复的元素
            child1 = deleteDuplicatedElementFromList3(child1)
            child2 = deleteDuplicatedElementFromList3(child2)
            parents[i],parents[i+1]=child1,child2
    return parents




def crossover(parents):  # 最终的交叉方法
    parents_front = parents[:optNumber]
    parents_behind = parents[optNumber:]
    # 开始进行交叉操作
    parents_front = crossover3(parents_front)  # 可以用2和3，，不可以用新的交叉方法crossover4
    parents_behind = crossover4(parents_behind)  # 2，3，4都可以用
    parents = parents_front + parents_behind
    return parents



def mutate3(parents): #两个点之间交换、逆转
    for i in range(len(parents)):
        rate=random.random()
        if rate<=pm:
            start, stop = sorted(random.sample(range(len(parents[i])), 2))
            # parents[i] = parents[i][:start] + parents[i][stop:start - 1:-1] + parents[i][stop + 1:]
            # parents[i] = parents[i][:start] + list(reversed(parents[i][start:stop]))+ parents[i][stop:]
            parents[i] = parents[i][:start] + parents[i][start:stop][::-1] + parents[i][stop:]
    return parents


def mutate2(parents): # 两个点之间交换
    for i in range(len(parents)):
        rate=random.random()
        if rate<=pm:
            p1, p2 = random.sample(range(len(parents[i])), 2)
            parents[i][p1], parents[i][p2] = parents[i][p2], parents[i][p1]
    return parents


def mutate(parents):
    mutate2(parents)
    mutate3(parents)
    return parents


def many2one2(solution):
    if len(solution)>24:
        solution=Eliminates_Route(solution)
    virtualNodes=list(range(101,131))
    newSolution = []
    for route,i in zip(solution,range(len(solution))):
        for c in route[1:-1]:
            newSolution.append(c)
        newSolution.append(virtualNodes[i])
    for j in range(i+1,len(virtualNodes)):
        newSolution.append(virtualNodes[j])
    return newSolution


def Artificial_Immune(population,fitnesses):  #6个个体
    for i in range(len(population)):
        population[i]=many2one2(population[i])
    best_fitness = float('inf')
    for i in range(100): # 迭代100次
        population=tournamentSelection(population,fitnesses) #锦标赛选择
        print('\nafter select')
        for individual, j in zip(population, range(len(population))):
            solution=one2many2(individual)
            a,b,c,d=solution_fitness(solution)
            fit=calFitness(a,b,c,d)
            print(fit, individual)
        population=crossover3(population)
        population=mutate(population)
        population,fitnesses,min_individual,min_fitness=ALNS(population)
        if min_fitness<=best_fitness:
            best_fitness=min_fitness
            best_individual=min_individual
        print('\n第',i,'代最优解：', min_fitness,min_individual)
        print('最优解：', best_fitness,best_individual)

    solution = one2many2(best_individual)
    print_solution(solution)
    print('目标值为：', best_fitness)
    plotRoutes(solution)


if __name__ == '__main__':
    start=time.time()
    algorithm='qita'
    population,fitnesses = initial_solution(algorithm)
    print('*******************AIA*********************')
    Artificial_Immune(population,fitnesses)
    end=time.time()
    print('Running time: %s Seconds' %(end-start))


