from random import choice
from copy import deepcopy
from utils import *
import copy

'''
初始路径的创建，按照数据ready_time首次分配车辆和城市，得到的是一个解
'''


def initial_solution3(algorithm):
    def sorted_readytime():  # 按照ready_time进行排序
        return list(sorted(global_customers, key=lambda customer: customer.ready_time))

    customers = sorted_readytime()

    def get_available_customers(customers):  # 还未访问过的顾客
        return list(filter(lambda customer: not customer.is_serviced, customers))

    customers = get_available_customers(customers)
    solution = []
    vehicleNo = 0
    while len(customers) > 0:  # 还有未访问过的顾客时进行循环
        vehicleNow = Vehicle(vehicleNo)
        vehicleNow.route = [depot.number]
        continue_count = 0
        capacity_temp = np.zeros(len(vehicleNow.capacity), dtype=int)
        deliCapa_temp = np.zeros(len(vehicleNow.deliCapa), dtype=int)
        last_customer = depot.number
        for customer in customers:  # 确定每一条路径的customer
            distance_depot = customer_distance_mat[customer.number][depot.number]
            start_service_time = max(customer.ready_time,
                                     vehicleNow.time + customer_distance_mat[last_customer][customer.number])
            time_temp = start_service_time + customer.service_time + distance_depot
            capacity_temp_sum = 0
            deliCapa_temp_sum = 0
            customer_pickup = deepcopy(customer.pickup)
            customer_delivery = deepcopy(customer.delivery)
            for i in range(len(vehicleNow.capacity)):
                capacity_temp[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
                capacity_temp_sum += capacity_temp[i]  # 如果总重量超过最大承载能力，换下一个顾客
                deliCapa_temp[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
                deliCapa_temp_sum += deliCapa_temp[i]  # 如果车上没有从仓库运来的物品了，换车
                customer_pickup[i] = 0
                customer_delivery[i] = 0
            if deliCapa_temp_sum < 0 or time_temp > depot.due_time or continue_count > 3:  # 换车
                break
            elif continue_count <= 3 and min(deliCapa_temp) < 0:  # 换下一个顾客
                # elif continue_count <= 3 and (capacity_temp_sum > vehicle_capacity or min(deliCapa_temp)<0): #换下一个顾客
                continue_count += 1
                continue
            else:
                vehicleNow.time, vehicleNow.capacity, vehicleNow.deliCapa = time_temp - distance_depot, capacity_temp, deliCapa_temp
                customer.pickup_request = customer_pickup
                customer.delivery_request = customer_delivery
                customer.is_serviced = True
                vehicleNow.route.append(customer.number)
            last_customer = customer.number
        vehicleNow.route.append(depot.number)
        solution.append(vehicleNow.route)
        customers = get_available_customers(customers)
        vehicleNo += 1
    a,b,c,d,e = solution_fitness(solution)
    fitness = calFitness(a,b,c,d,e)
    if algorithm == 'TS':
        return solution, fitness


def getListMaxNumIndex(num_list, topk):
    '''
    获取列表中最大的前n个数值的位置索引
    '''
    tmp_list = copy.deepcopy(num_list)
    tmp_list.sort()
    # max_num_index = [num_list.index(one) for one in tmp_list[::-1][:topk]]
    min_num_index = [num_list.index(one) for one in tmp_list[:topk]]
    return min_num_index


'''
ETRC启发式构建初始解
'''
def initial_solution(algorithm):
    print('***********************init***************************')
    a = 0
    ab_solution = []  # 每一轮ab，收纳的是每一轮seeds中最好的solution
    ab_fitness = []
    ab_vehicle=[]
    while a <= 1:
        a += 1 / (customers_account - 1)
        b = 1 - a
        seed_solution = []  # 每一轮seeds的所有solution
        seed_fitness = []
        seed_vehicle=[]
        seeds = deepcopy(global_customers)[1:]  # 作为种子的顾客
        while len(seeds) > 0:
            # 得到一个解
            solution, fitness, vehicles = initial_seeds(seeds, a, b)
            seed_solution.append(solution)
            seed_fitness.append(fitness)
            seed_vehicle.append(vehicles)
        # 寻找每一轮seed中的最小值添加到ab中
        min_index = seed_fitness.index(min(seed_fitness))
        ab_fitness.append(min(seed_fitness))
        ab_solution.append(seed_solution[min_index])
        ab_vehicle.append(seed_vehicle[min_index])
    all_min_index = ab_fitness.index(min(ab_fitness))
    if algorithm == 'TS':
        return ab_solution[all_min_index], min(ab_fitness)
        # return ab_solution,ab_fitness
    else:
        # return ab_solution, ab_fitness
        solutions = []
        fitnesses = []
        vehicleses=[]
        min_num_index = getListMaxNumIndex(ab_fitness, 100) #初始解得到10个
        for x in min_num_index:
            solutions.append(ab_solution[x])
            fitnesses.append(ab_fitness[x])
            vehicleses.append(ab_vehicle[x])
        return solutions, fitnesses, vehicleses
        # return fitness_sum / 10, len_sum /10,min(ab_fitness),len(ab_solution[all_min_index])


def initial_seeds(seeds, a, b):
    filename, global_customers, vehicle_number, vehicle_capacity = get_customers(globalPath)
    customers = deepcopy(global_customers)[1:]
    customers = sorted_criterion(customers, a, b)
    # customers = get_available_customers(customers)
    solution = []
    vehicleNo = 0
    vehicles = []
    while len(customers) > 0:  # 还有未访问过的顾客时进行循环
        vehicleNow = Vehicle(vehicleNo)
        vehicleNow.setCapacity()
        continue_count = 0
        vehicleNow.route = [depot.number]
        # common = [x for x in seeds if x in customers]  # 既在seeds中还在customers
        common = []
        for i in range(len(seeds)):
            for j in range(len(customers)):
                if seeds[i].number == customers[j].number:
                    common.append(seeds[i])
        if len(common) == 0:
            seed = choice(customers)
            customers.remove(seed)  # 这句因为下面的is_serviced可能不需要，再看看
        else:
            seed = choice(common)
            seeds.remove(seed)
            for j in range(len(customers)):
                if seed.number == customers[j].number:
                    seed = customers[j]
            customers.remove(seed)
        vehicleNow.route.append(seed.number)
        # 选择seed后更改时间容量等，将seed的pickup和delivery按照要求
        vehicleNow.distance += customer_distance_mat[depot.number][seed.number]
        vehicleNow.time = max(vehicleNow.distance, seed.ready_time) + seed.service_time
        for i in range(len(vehicleNow.capacity)):
            vehicleNow.capacity[i] = vehicleNow.capacity[i] + seed.pickup[i] - seed.delivery[i]
            vehicleNow.deliCapa[i] = vehicleNow.deliCapa[i] - seed.delivery[i]  # 计算每类产品从车上运下去了多少
            seed.pickup[i], seed.delivery[i] = 0, 0
        seed.is_serviced = True

        last_customer = seed.number
        ################# 开始循环
        for customer in customers:  # 确定每一条路径的customer
            distance_depot = customer_distance_mat[customer.number][depot.number]
            start_service_time = max(customer.ready_time,
                                     vehicleNow.time + customer_distance_mat[last_customer][customer.number])
            time_temp = start_service_time + customer.service_time + distance_depot
            capacity_temp_sum = 0
            deliCapa_temp_sum = 0
            capacity_temp = np.zeros(len(vehicleNow.capacity), dtype=int)
            deliCapa_temp = np.zeros(len(vehicleNow.deliCapa), dtype=int)
            for i in range(len(vehicleNow.capacity)):
                capacity_temp[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
                capacity_temp_sum += capacity_temp[i]  # 如果总重量超过最大承载能力，换下一个顾客
                deliCapa_temp[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
                deliCapa_temp_sum += deliCapa_temp[i]  # 如果车上没有从仓库运来的物品了，换车
            # if capacity_temp_sum > vehicleNow.vehicle_capacity or min(deliCapa_temp) < 0 or time_temp > depot.due_time:
            if time_temp > depot.due_time or deliCapa_temp_sum < 0 or continue_count > 2:  # 换车
                break
            # elif continue_count <= 3 and min(deliCapa_temp)<0: #换下一个顾客 ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
            elif continue_count < 3 and (capacity_temp_sum > vehicleNow.vehicle_capacity or min(deliCapa_temp) < 0):  # 换下一个顾客
                continue_count += 1
                continue
            else:
                vehicleNow.time, vehicleNow.capacity, vehicleNow.deliCapa = time_temp - distance_depot, capacity_temp, deliCapa_temp
                customer.pickup_request = [0,0,0,0,0]
                customer.delivery_request = [0,0,0,0,0]
                customer.is_serviced = True
                vehicleNow.route.append(customer.number)
            last_customer = customer.number
        vehicleNow.route.append(depot.number)
        solution.append(vehicleNow.route)
        customers = get_available_customers(customers)
        vehicles.append(vehicleNow)
        vehicleNo += 1
    a,b,c,d,e = solution_fitness(solution)
    fitness = calFitness(a,b,c,d,e)
    return solution, fitness, vehicles


if __name__ == '__main__':
    solutions, fitnesses = initial_solution('ETRC')
    print('共生成几个解',len(solutions))
    # solution2,fitness2=initial_solution2('TS')
    # print_solution(solution)
    # print('ETRC',fitness)
    # print('其他',fitness2)

    # ab_solution, ab_fitness = initial_solution(algorithm)
    # for i in range(len(ab_fitness)):
    #     print_solution(ab_solution[i])
    #     print(ab_fitness[i])