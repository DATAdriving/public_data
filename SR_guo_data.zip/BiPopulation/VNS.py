from initial import *
import random
import copy

def intra_swap(a, i, j): #路径内交换
    a[i], a[j] = a[j], a[i]
    return a

def inter_swap(a, b, i, j): #路径间交换
    a[i], b[j] = b[j], a[i]
    return a, b

def intra_relocation(a, i, j): #路径内重定位客户位置
    customer = a.pop(i)
    a.insert(j, customer)
    return a

def inter_relocation(a, b, i, j): #路径间重定位客户位置
    customer = a.pop(i)
    b.insert(j, customer)
    return a, b


class VNS:
    def __init__(self, solution,fitness):
        self.solution = solution
        self.fitness=fitness


    def bestNeighbor(self, number):
        func_dict = {0: self.Intra_Route_Swap,
                     1: self.Inter_Route_Swap,
                     2: self.Intra_Route_Relocation,
                     3: self.Inter_Route_Relocation,
                     4: self.Eliminates_Random_Route,
                     5: self.Eliminates_Smallest_Route,

                     }
        return func_dict.get(number)()


    '''
    同一路径，交换客户位置
    '''
    def Intra_Route_Swap(self): #路径内交换
        solution = copy.deepcopy(self.solution)
        random_route_index = random.randint(0, len(solution)-1) # 从解中选一条路径
        random_route=solution[random_route_index]
        if len(random_route) > 3:
            # print('对第' + str(random_route) + '条路径进行swap')
            oldFit = route_fitness(random_route, random_route_index)
            location_i = random.randint(1, len(random_route) - 2) #选择非depot的点
            location_j = random.randint(1, len(random_route) - 2)
            route_new = intra_swap(random_route, location_i, location_j)
            newFit=route_fitness(route_new, random_route_index)
            solution[random_route_index] = route_new
            fitness=inRoute_fitness(self.fitness, oldFit, newFit)
            return solution,fitness
        else:
            return self.solution,self.fitness


    '''
    不同路径交换客户位置
    '''
    def Inter_Route_Swap(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        solution_lengh = [i for i in range(len(solution))]
        res = random.sample(solution_lengh, 2) #选择两个不同的数
        random_route1, random_route2 = list(map(int, res))
        route1,route2=solution[random_route1],solution[random_route2]
        if len(route1) > 3 and len(route2) > 3:
            # print('对第' + str(random_route1) + '和' + str(random_route2)+'条路径进行swap')
            oldFit1=route_fitness(route1, random_route1)
            oldFit2=route_fitness(route2, random_route2)
            location_i = random.randint(1, len(route1) - 2) # 选择非depot的点
            location_j = random.randint(1, len(route2) - 2)
            route_new1, route_new2 = inter_swap(route1, route2, location_i, location_j)
            newFit1=route_fitness(route_new1, random_route1)
            newFit2=route_fitness(route_new2, random_route2)
            solution[random_route1], solution[random_route2] = route_new1, route_new2
            fitness=outRoute_fitness(self.fitness, oldFit1, newFit1, oldFit2, newFit2)
            return solution,fitness
        else:
            return self.solution,self.fitness

    '''
    同一条路径,重定位客户位置
    '''
    def Intra_Route_Relocation(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        random_route_index = random.randint(0, len(solution)-1)  #从解中选一条路径
        random_route=solution[random_route_index]
        if len(random_route) > 3:
            # print('对第' + str(random_route + 1) + '条路径进行relocation')
            oldFit = route_fitness(random_route, random_route_index)
            location_i = random.randint(1, len(random_route) - 2) #选择非depot的点
            location_j = random.randint(1, len(random_route) - 2)
            route_new = intra_relocation(random_route, location_i, location_j)
            newFit = route_fitness(route_new, random_route_index)
            solution[random_route_index] = route_new
            fitness=inRoute_fitness(self.fitness, oldFit, newFit)
            return solution, fitness
        else:
            return self.solution,self.fitness


    '''
    不同路径，重定位客户位置
    '''
    def Inter_Route_Relocation(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        solution_lengh = [i for i in range(len(solution))]
        res = random.sample(solution_lengh, 2) # 选择两个不同的数
        random_route1, random_route2 = list(map(int, res))
        route1, route2 = solution[random_route1], solution[random_route2]
        if len(route1)>3 and len(route2)>3:
            # print('对第' + str(random_route1) + '和' + str(random_route2)+'条路径进行relocation')
            oldFit1 = route_fitness(route1, random_route1)
            oldFit2 = route_fitness(route2, random_route2)
            location_i = random.randint(1, len(route1) - 2) #选择非depot的点
            location_j = random.randint(1, len(route2) - 2)
            route_new1, route_new2 = inter_relocation(route1, route2, location_i, location_j)
            newFit1 = route_fitness(route_new1, random_route1)
            newFit2 = route_fitness(route_new2, random_route2)
            solution[random_route1], solution[random_route2] = route_new1, route_new2
            fitness = outRoute_fitness(self.fitness, oldFit1, newFit1, oldFit2, newFit2)
            return solution,fitness
        else:
            return self.solution,self.fitness

    '''
    消除最小路径
    list[], range:
    0 1 2 3 4 5 0   len = 7    1-5
      1 2 3 4 5     [1:6]
    random.randint(1,100):
        包括1和100
    '''
    def Eliminates_Smallest_Route(self):
        solution = copy.deepcopy(self.solution)
        route_length=[len(route) for route in solution]
        small_vehicleNo = route_length.index(min(route_length)) # 选择最小路径,vehicle_No
        small_route = solution[small_vehicleNo]
        # print('消除最小路径' + str(small_vehicleNo))
        while len(small_route)>2:
            for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route)-1))): #去掉depot
                customer = small_route.pop(i)
                random_route_index = random.randint(0, len(solution)-1)  # 从解中选一条路径
                random_route = solution[random_route_index]
                random_location = random.randint(1, len(random_route) - 1) # random.randint就是-1，位置可以是后一位，不用改！选择非第一个depot的点
                random_route.insert(random_location, customer)
        del solution[small_vehicleNo]
        a,b,c,d,e=solution_fitness(solution)
        fitness=calFitness(a,b,c,d,e)
        return solution,fitness


    def Eliminates_Random_Route(self):
        solution = copy.deepcopy(self.solution)
        random_route_No = random.randint(0, len(solution)-1)  #从解中选一条路径
        small_route = solution[random_route_No]
        # print('消除最小路径' + str(small_vehicleNo))
        while len(small_route)>2:
            for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route)-1))): #去掉depot
                customer = small_route.pop(i)
                random_route_index = random.randint(0, len(solution)-1)  # 从解中选一条路径
                random_route = solution[random_route_index]
                random_location = random.randint(1, len(random_route) - 1) # random.randint就是-1，位置可以是后一位，不用改！选择非第一个depot的点
                random_route.insert(random_location, customer)
        del solution[random_route_No]
        a, b, c, d, e = solution_fitness(solution)
        fitness = calFitness(a, b, c, d,e)
        return solution, fitness

    def Eliminates_Route(self):
        solution = copy.deepcopy(self.solution)
        count=0
        while count<6:
            count+=1
            route_length = [len(route) for route in solution]
            small_vehicleNo = route_length.index(min(route_length))  # 选择最小路径,vehicle_No
            small_route = solution[small_vehicleNo]
            # print('消除最小路径' + str(small_vehicleNo))
            while len(small_route) > 2:
                for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route) - 1))):  # 去掉depot
                    customer = small_route.pop(i)
                    for m in range(len(solution)):
                        routem = solution[m]
                        for n in range(1, len(routem)):
                            routem.insert(n, customer)
                            routem_newFit = route_fitness(routem, m)
                            if routem_newFit[0]==False:
                                routem.pop(n)
                            else:
                                break
            del solution[small_vehicleNo]
        return solution

def VNS_implement(solution):
    # print('开始VNS')
    # print_solution(solution)
    Best_solution = copy.deepcopy(solution)
    a,b,c,d,e = solution_fitness(Best_solution)
    Best_fitness=calFitness(a,b,c,d,e)
    iteration = 100
    for number in range(iteration):
        # print('迭代次数',number)
        temp_solution = VNS(Best_solution).bestNeighbor(number % 4)
        temp_solution = VNS(temp_solution).Eliminates_Smallest_Route()
        # temp_solution = VNS(Best_solution).Inter_Route_Swap()
        # temp_solution = VNS(Best_solution).Inter_Route_Relocation()
        # temp_solution = VNS(Best_solution).Intra_Route_Relocation()
        a,b,c,d,e = solution_fitness(temp_solution)
        temp_fitness=calFitness(a,b,c,d,e)
        if temp_fitness < Best_fitness:
            # print('VNS: temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
            Best_solution = copy.deepcopy(temp_solution)
            Best_fitness = temp_fitness
    return Best_solution,Best_fitness


def VNS_implement2(solution,fitness):
    Best_solution = copy.deepcopy(solution)
    Best_fitness = fitness
    iteration = 100
    number=0
    isFL=[] #0代表不可行，1代表可行
    for i in range(iteration):
        temp_solution,temp_fitness = VNS(Best_solution,Best_fitness).bestNeighbor(number % 4)
        # vehicleNumber, distance, fuelConsumption, punish = solution_fitness(temp_solution)
        # temp_fitness = calFitness(vehicleNumber, distance, fuelConsumption, punish)
        if temp_fitness < Best_fitness:
            print('VNS: temp_fitness', temp_fitness, '    Best_fitness', Best_fitness)
            Best_solution = copy.deepcopy(temp_solution)
            Best_fitness = temp_fitness
            isFL.append(True)
        elif i>3 and isFL[i-1]==False and isFL[i-2]==False and isFL[i-3]==False:
            isFL.append(True)
            number+=1
        else:
            isFL.append(False)
    return Best_solution,Best_fitness


if __name__ =='__main__':
    start=time.time()
    algorithm = 'TS'
    solution, fitness = initial_solution(algorithm)
    # print_solution(solution)
    for i in range(100):
        solution,fitness=VNS_implement(solution)
    # print_solution(solution)
    end=time.time()
    print('%s' % (end - start),fitness)
