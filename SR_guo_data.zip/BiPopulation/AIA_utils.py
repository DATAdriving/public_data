from structure import *
from copy import deepcopy
from utils import *
import copy
import pandas as pd

def deleteDuplicatedElementFromList3(listA):
    # return list(set(listA))
    return sorted(set(listA), key=listA.index)


def getListMaxNumIndex(num_list, topk):
    '''
    获取列表中最小的前n个数值的位置索引
    '''
    tmp_list = copy.deepcopy(num_list)
    tmp_list.sort()
    # max_num_index = [num_list.index(one) for one in tmp_list[::-1][:topk]]
    min_num_index = [num_list.index(one) for one in tmp_list[:topk]]
    return min_num_index

def get_list_min_index(list_, n):
    """
    计算列表中最大的N个数对应的索引
    :param list_: 要分析的列表(list)
    :param n: 截取最大的n个数(int)
    :return: 最大n个数的索引
    """
    N_large = pd.DataFrame({'score': list_}).sort_values(by='score', ascending=[True])
    return list(N_large.index)[:n]



# 解中的路径太多了，消除几个最短路径
def Eliminates_Route(solution):
    route_length = [len(route) for route in solution]
    # min_list=getListMaxNumIndex(route_length,30) #数目少的路径的索引列表
    # 数目少的路径的索引列表
    min_list = get_list_min_index(route_length,30)
    for small_vehicleNo in min_list:
        small_route=solution[small_vehicleNo]
        # 对路径中的每一个顾客进行弹出插入到别的路径
        for i in reversed(range(1, len(small_route)-1)):
            c=small_route.pop(i)
            c_ok=False
            for m in range(len(solution)):
                routem = solution[m]
                if m!=small_vehicleNo:
                    # 对每一个插入位置来说，n是位置
                    for n in range(1, len(routem)):
                        routem.insert(n,c)
                        routem_newFit=route_fitness(routem,m)
                        if routem_newFit[0]==True: #插入顾客后路径是可行的
                            break #按道理来说接下来就去遍历下一个c
                        else: # 插入路径后不可行
                            routem.pop(n)
                if c in routem:  # 插入路径之后可行，跳出对每条路径的循环
                    c_ok=True
                    break
            if c_ok==False:# 这个c没有地方可以插入的话
                small_route.insert(c,i)
        num=0
        for route in solution:
            if len(route)>2:
                num+=1
        if num<30:
            break
    for j in reversed(range(len(solution))):
        if len(solution[j])==2:
            del solution[j]
    return solution



def one2many2(individual): # 无0到有0
    solution=[]
    route = [0]
    for x in individual:
        if x<=100:
            route.append(x)
        elif x>100:
            route.append(0)
            solution.append(route)
            route=[0]
    if route[-1]!=0:
        route.append(0)
        solution.append(route)
    for route in reversed(solution):
        if len(route)==2:
            solution.remove(route)
    return solution


def many2one2(solution):
    if len(solution) > 29:
        # print('many2one2用到了消除路径')
        solution = Eliminates_Route(solution)
    if len(solution) > 29:
        # print('many2one2用到了消除路径')
        solution = Eliminates_Route(solution)
    virtualNodes=list(range(101,131))
    newSolution = []
    for route,i in zip(solution,range(len(solution))):
        for c in route[1:-1]:
            newSolution.append(c)
        newSolution.append(virtualNodes[i])
    for j in range(i+1,len(virtualNodes)):
        newSolution.append(virtualNodes[j])
    return newSolution



def many2one(solution): # 有0到无0
    newSolution=[]
    for route in solution:
        for c in route[1:-1]:
            newSolution.append(c)
    return newSolution

def one2many(individual): # 无0到有0
    solution=[]
    vehicleNo = 0
    vehicleNow = Vehicle(vehicleNo)
    vehicleNow.route = [depot.number]
    capacity_temp = np.zeros(len(vehicleNow.capacity), dtype=int)
    deliCapa_temp = np.zeros(len(vehicleNow.deliCapa), dtype=int)
    number_last=depot.number
    for number in individual:
        for i in global_customers:
            if i.number == number:
                customer = i
        start_service_time = max(customer.ready_time, vehicleNow.time+customer_distance_mat[number_last][number])#!!!!!!!
        distance_depot=customer_distance_mat[number][depot.number]
        time_temp = start_service_time + customer.service_time+distance_depot
        capacity_temp_sum = 0
        deliCapa_temp_sum = 0
        customer_pickup = deepcopy(customer.pickup)
        customer_delivery = deepcopy(customer.delivery)
        for i in range(len(vehicleNow.capacity)):
            capacity_temp[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
            capacity_temp_sum += capacity_temp[i]  # 如果总重量超过最大承载能力，换下一个顾客
            deliCapa_temp[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
            deliCapa_temp_sum += deliCapa_temp[i]  # 如果车上没有从仓库运来的物品了，换车
            customer_pickup[i] = 0
            customer_delivery[i] = 0
        if deliCapa_temp_sum < 0 or time_temp > depot.due_time:  # 换车
            vehicleNow.route.append(depot.number)
            solution.append(vehicleNow.route)
            # Initialize a new sub-route and add to it
            vehicleNo+=1
            vehicleNow=Vehicle(vehicleNo)
            vehicleNow.route = [0,number]
            for i in range(len(vehicleNow.capacity)):
                vehicleNow.capacity[i] = vehicleNow.capacity[i] + customer.pickup[i] - customer.delivery[i]
                vehicleNow.deliCapa[i] = vehicleNow.deliCapa[i] - customer.delivery[i]  # 计算每类产品从车上运下去了多少
            vehicleNow.time=max(customer_distance_mat[depot.number][customer.number],customer.ready_time)+customer.service_time
        else:
            vehicleNow.time, vehicleNow.capacity, vehicleNow.deliCapa = time_temp-distance_depot, capacity_temp, deliCapa_temp
            customer.pickup_request = customer_pickup
            customer.delivery_request = customer_delivery
            customer.is_serviced = True
            vehicleNow.route.append(customer.number)
        number_last=customer.number
    vehicleNow.route.append(depot.number)
    solution.append(vehicleNow.route)
    return solution


def calDensity(population,fitnesses):
    # 计算 fitness/1000
    fitness=[]
    for i in range(len(population)):
        fitness.append(fitnesses[i]/1000)

    densityTable=np.zeros((len(population),len(population)))
    density=np.zeros(len(population))

    for i in range(len(population)):
        for j in range(len(population)):
            if fitness[i]==fitness[j]:
                densityTable[i][j]=1
            else:
                densityTable[i][j]=1/(1+abs(fitness[i]-fitness[j]))
    for i in range(len(population)):
        density[i]=0
        density[i]+=1/len(population)*sum(densityTable[i])
    return fitness,density