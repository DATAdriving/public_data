import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

data = {
    'A': [1000, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2500],
    'B': [1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000, 2100],
    'C': [1000, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000],
    "D": [800, 1000, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900]
}
df = pd.DataFrame(data)
df.plot.box(title="example show")
plt.grid(linestyle="--", alpha=0.3)
plt.savefig('./results_imgs.png', bbox_inches='tight')
plt.show()