from initial import *
import random
import copy

def intra_swap(a, i, j): #路径内交换
    a[i], a[j] = a[j], a[i]
    return a

def inter_swap(a, b, i, j): #路径间交换
    a[i], b[j] = b[j], a[i]
    return a, b

def intra_relocation(a, i, j): #路径内重定位客户位置
    customer = a.pop(i)
    a.insert(j, customer)
    return a

def inter_relocation(a, b, i, j): #路径间重定位客户位置
    customer = a.pop(i)
    b.insert(j, customer)
    return a, b


class Pertur:
    def __init__(self, solution):
        self.solution = solution

    def bestNeighbor(self, number):
        func_dict = {0: self.Intra_Route_Swap,
                     1: self.Inter_Route_Swap,
                     2: self.Intra_Route_Relocation,
                     3: self.Inter_Route_Relocation,
                     4: self.Eliminates_Random_Route,
                     5: self.Eliminates_Smallest_Route,

                     }
        return func_dict.get(number)()


    '''
    同一路径，交换客户位置
    '''
    def Intra_Route_Swap(self): #路径内交换
        solution = self.solution
        solution = copy.deepcopy(solution)
        random_route = random.randint(0, len(solution)-1) # 从解中选一条路径
        if len(solution[random_route]) > 3:
            # print('对第' + str(random_route) + '条路径进行swap')
            location_i = random.randint(1, len(solution[random_route]) - 2) #选择非depot的点
            location_j = random.randint(1, len(solution[random_route]) - 2)
            route_new = intra_swap(solution[random_route], location_i, location_j)
            solution[random_route] = route_new
        return solution

    '''
    不同路径交换客户位置
    '''
    def Inter_Route_Swap(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        solution_lengh = [i for i in range(len(solution))]
        res = random.sample(solution_lengh, 2) #选择两个不同的数
        random_route1, random_route2 = list(map(int, res))
        if len(solution[random_route1]) > 3 and len(solution[random_route2]) > 3:
            # print('对第' + str(random_route1) + '和' + str(random_route2)+'条路径进行swap')
            location_i = random.randint(1, len(solution[random_route1]) - 2) # 选择非depot的点
            location_j = random.randint(1, len(solution[random_route2]) - 2)
            route_new1, route_new2 = inter_swap(solution[random_route1], solution[random_route2], location_i, location_j)
            solution[random_route1], solution[random_route2] = route_new1, route_new2
        return solution

    '''
    同一条路径,重定位客户位置
    '''
    def Intra_Route_Relocation(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        random_route = random.randint(0, len(solution)-1)  #从解中选一条路径
        if len(solution[random_route]) > 3:
            # print('对第' + str(random_route + 1) + '条路径进行relocation')
            location_i = random.randint(1, len(solution[random_route]) - 2) #选择非depot的点
            location_j = random.randint(1, len(solution[random_route]) - 2)
            route_new = intra_relocation(solution[random_route], location_i, location_j)
            solution[random_route] = route_new
        return solution

    '''
    不同路径，重定位客户位置
    '''
    def Inter_Route_Relocation(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        solution_lengh = [i for i in range(len(solution))]
        res = random.sample(solution_lengh, 2) # 选择两个不同的数
        random_route1, random_route2 = list(map(int, res))
        if len(solution[random_route1])>3 and len(solution[random_route2])>3:
            # print('对第' + str(random_route1) + '和' + str(random_route2)+'条路径进行relocation')
            location_i = random.randint(1, len(solution[random_route1]) - 2) #选择非depot的点
            location_j = random.randint(1, len(solution[random_route2]) - 2)
            route_new1, route_new2 = inter_relocation(solution[random_route1], solution[random_route2], location_i, location_j)
            solution[random_route1], solution[random_route2] = route_new1, route_new2
        return solution

    '''
    消除最小路径
    list[], range:
    0 1 2 3 4 5 0   len = 7    1-5
      1 2 3 4 5     [1:6]
    random.randint(1,100):
        包括1和100
    '''
    def Eliminates_Smallest_Route(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        route_length=[len(route) for route in solution]
        small_vehicleNo = route_length.index(min(route_length)) # 选择最小路径,vehicle_No
        small_route = solution[small_vehicleNo]
        # print('消除最小路径' + str(small_vehicleNo))
        while len(small_route)>2:
            for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route)-1))): #去掉depot
                customer = small_route.pop(i)
                random_route_index = random.randint(0, len(solution)-1)  # 从解中选一条路径
                random_route = solution[random_route_index]
                random_location = random.randint(1, len(random_route) - 1) # random.randint就是-1，位置可以是后一位，不用改！选择非第一个depot的点
                random_route.insert(random_location, customer)
        del solution[small_vehicleNo]
        return solution


    def Eliminates_Random_Route(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        random_route_No = random.randint(0, len(solution)-1)  #从解中选一条路径
        small_route = solution[random_route_No]
        # print('消除最小路径' + str(small_vehicleNo))
        while len(small_route)>2:
            for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route)-1))): #去掉depot
                customer = small_route.pop(i)
                random_route_index = random.randint(0, len(solution)-1)  # 从解中选一条路径
                random_route = solution[random_route_index]
                random_location = random.randint(1, len(random_route) - 1) # random.randint就是-1，位置可以是后一位，不用改！选择非第一个depot的点
                random_route.insert(random_location, customer)
        del solution[random_route_No]
        return solution

    def Eliminates_Route(self):
        solution = self.solution
        solution = copy.deepcopy(solution)
        count=0
        while count<6:
            count+=1
            route_length = [len(route) for route in solution]
            small_vehicleNo = route_length.index(min(route_length))  # 选择最小路径,vehicle_No
            small_route = solution[small_vehicleNo]
            # print('消除最小路径' + str(small_vehicleNo))
            while len(small_route) > 2:
                for customer, i in zip(reversed(small_route[1: -1]), reversed(range(1, len(small_route) - 1))):  # 去掉depot
                    customer = small_route.pop(i)
                    for m in range(len(solution)):
                        routem = solution[m]
                        for n in range(1, len(routem)):
                            routem.insert(n, customer)
                            routem_newFit = route_fitness(routem, m)
                            if routem_newFit[0]==False:
                                routem.pop(n)
                            else:
                                break
            del solution[small_vehicleNo]
        return solution






