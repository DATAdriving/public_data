# 随机生成数据文件
import random
import os


def generate(from_filename,to_filename):
    # 读取原数据文件
    #print(to_filename)
    with open(from_filename, 'r') as file:
        lines = file.readlines()
        lines = list(map(lambda l: l.replace('\n', ''), lines))  # 替换\n为空，将map转换为list
    file.close()

    # 重新写入文件
    with open(to_filename, 'w') as file:
        for line in range(len(lines)):
            if line == 0:
                lines[line] = to_filename[8:-4] + '\n'
                file.write(lines[line])
            elif line in range(1,7):
                file.write(lines[line]+'\n')
            elif line == 7:
                file.write('CUST_NO.   XCOORD.   YCOORD.   Earliest   Latest    duration  ')
                file.write('{:>8}'.format('pickup1') + '{:>10}'.format('delivery1'))
                file.write('{:>8}'.format('pickup2') + '{:>10}'.format('delivery2'))
                file.write('{:>8}'.format('pickup3') + '{:>10}'.format('delivery3'))
                file.write('{:>8}'.format('pickup4') + '{:>10}'.format('delivery4'))
                file.write('{:>8}'.format('pickup5') + '{:>10}'.format('delivery5')+'\n')
            elif line == 8:
                pass
            elif line == 9:
                #lines[line] += '{:>8}'.format(str(0))+'\n'
                lines[line] = lines[line][:33] + lines[line][43:]
                lines[line] += ('{:>8}'.format(str(0)) + '{:>10}'.format(str(0)))*5+'\n'
                file.write(lines[line])
            else:
                lines[line] = lines[line][:33] + lines[line][43:]
                for i in range(5):
                    pickup = str(random.randrange(0, 5, 1))
                    delivery = str(random.randrange(0, 8, 2))
                    if pickup=='0' or delivery=='0':
                        pickup,delivery=str(0),str(0)
                    lines[line] += '{:>8}'.format(pickup) + '{:>10}'.format(delivery)
                lines[line] += '\n'
                file.write(lines[line])
    file.close()




if __name__ == '__main__':
    from_path = '.\instances\\'
    to_path = '.\data\\'
    for filename in os.listdir(from_path):
        from_filename = from_path+filename
        to_filename = to_path+'dp'+filename
        generate(from_filename, to_filename)
